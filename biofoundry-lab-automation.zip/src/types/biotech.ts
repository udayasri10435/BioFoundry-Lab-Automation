export type IndustryProfile = 'genomics' | 'synbio' | 'cro';

export type StepType = 
  | 'pipette_transfer'
  | 'multichannel_transfer'
  | 'thermocycle'
  | 'magnetic_bead'
  | 'incubate_shake'
  | 'centrifuge'
  | 'plate_reader'
  | 'colony_pick';

export type LiquidClass = 'water' | 'viscous_glycerol' | 'volatile_ethanol' | 'dna_high_salt' | 'mastermix';

export interface ProtocolStep {
  id: string;
  name: string;
  type: StepType;
  description: string;
  durationSeconds: number;
  parameters: {
    // Pipetting params
    sourceSlot?: number;
    sourceWellRange?: string;
    destinationSlot?: number;
    destinationWellRange?: string;
    volumeMicroLitres?: number;
    liquidClass?: LiquidClass;
    aspirateSpeedMmSec?: number;
    dispenseSpeedMmSec?: number;
    tipHandling?: 'new_tip_always' | 'reuse_tip' | 'change_between_columns';
    mixCycles?: number;
    mixVolumeMicroLitres?: number;
    touchTip?: boolean;
    airGapMicroLitres?: number;
    
    // Thermocycler params
    lidTemperatureCelsius?: number;
    stages?: {
      name: string;
      cycles: number;
      steps: { temperatureCelsius: number; holdTimeSeconds: number }[];
    }[];
    
    // Magnetic Bead params
    bindingTimeMinutes?: number;
    magnetEngageHeightMm?: number;
    separationTimeMinutes?: number;
    washCycles?: number;
    ethanolPercentage?: number;
    dryingTimeMinutes?: number;
    elutionVolumeMicroLitres?: number;
    
    // Shaker / Incubator params
    temperatureCelsius?: number;
    shakeRpm?: number;
    shakeDurationMinutes?: number;
    
    // Centrifuge params
    speedRcf?: number;
    spinTimeSeconds?: number;
    
    // Plate reader params
    readMode?: 'absorbance' | 'fluorescence' | 'luminescence';
    wavelengthNm?: number;
    
    // Colony picker params
    targetCount?: number;
    fluorescenceFilter?: string;
  };
}

export type LabwareType = 
  | 'tiprack_20ul'
  | 'tiprack_200ul'
  | 'tiprack_1000ul'
  | 'plate_96_pcr'
  | 'plate_96_deepwell'
  | 'plate_384_optical'
  | 'reservoir_12_channel'
  | 'magnetic_module'
  | 'thermocycler_module'
  | 'heater_shaker_module'
  | 'trash_chute';

export interface DeckSlot {
  slotNumber: number;
  labwareType: LabwareType | null;
  name: string;
  isOccupied: boolean;
  currentTipsRemaining?: number;
  maxTips?: number;
  moduleState?: {
    temperatureCelsius?: number;
    targetTemperatureCelsius?: number;
    isShaking?: boolean;
    rpm?: number;
    isEngaged?: boolean;
  };
}

export interface Instrument {
  id: string;
  name: string;
  model: string;
  manufacturer: string;
  category: 'liquid_handler' | 'thermocycler' | 'sequencer' | 'plate_reader' | 'colony_picker' | 'incubator';
  status: 'running' | 'idle' | 'warning' | 'error' | 'offline';
  silaStatus: 'connected' | 'handshaking' | 'disconnected';
  activeProtocolName?: string;
  currentStepIndex?: number;
  totalSteps?: number;
  progressPercent: number;
  elapsedSeconds: number;
  estimatedRemainingSeconds: number;
  telemetry: {
    deckTempCelsius: number;
    ambientTempCelsius: number;
    pressureLldMbar: number; // Pressure Liquid Level Sensing
    wasteLevelPercent: number;
    pipetteChannelHealth: boolean[];
    lastCalibrationDate: string;
  };
}

export interface WellSample {
  wellId: string; // e.g., "A1", "H12"
  row: string; // "A" - "H" or "A" - "P"
  column: number; // 1 - 12 or 1 - 24
  sampleId: string | null;
  sampleName: string | null;
  organismOrConstruct?: string;
  sampleType: 'gDNA' | 'cDNA' | 'plasmid' | 'oligo' | 'cell_lysate' | 'buffer' | 'neg_control' | 'pos_control' | 'compound' | 'empty';
  volumeMicroLitres: number;
  maxVolumeMicroLitres: number;
  concentrationNgUl: number;
  purityA260A280: number;
  qcStatus: 'passed' | 'warning' | 'failed' | 'untested' | 'empty';
  freezeThawCycles: number;
  parentTubeBarcode?: string;
  barcode: string;
  notes?: string;
}

export interface Microplate {
  id: string;
  barcode: string;
  name: string;
  format: '96' | '384';
  plateType: 'pcr' | 'deep_well' | 'optical' | 'assay';
  wells: Record<string, WellSample>;
  createdAt: string;
  updatedAt: string;
  assignedWorkOrderId?: string;
}

export interface WorkOrder {
  id: string;
  orderNumber: string;
  title: string;
  assayType: string;
  sampleCount: number;
  submitter: string;
  operator: string;
  status: 'queued' | 'in_progress' | 'qc_review' | 'completed' | 'on_hold';
  priority: 'routine' | 'urgent' | 'stat';
  createdAt: string;
  dueDate: string;
  protocolId: string;
  inputPlateBarcodes: string[];
  outputPlateBarcodes: string[];
  notes: string;
}

export interface Reagent {
  id: string;
  name: string;
  catalogNumber: string;
  lotNumber: string;
  vendor: string;
  expirationDate: string;
  storageCondition: '-80°C' | '-20°C' | '4°C' | '15-25°C (Ambient)';
  currentVolumeMl: number;
  initialVolumeMl: number;
  freezeThawCount: number;
  maxFreezeThaw: number;
  hazardClass: ('flammable' | 'corrosive' | 'toxic' | 'none')[];
  inUseDeckSlot?: number;
}

export interface ELNAuditEntry {
  id: string;
  timestamp: string;
  operator: string;
  action: string;
  details: string;
  signatureHash: string; // 21 CFR Part 11 SHA256 simulation
  verified: boolean;
}
