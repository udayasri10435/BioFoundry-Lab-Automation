import React, { useState, useEffect } from 'react';
import { Instrument } from '../../types/biotech';
import { 
  X, 
  Activity, 
  Radio, 
  Terminal, 
  Cpu, 
  ArrowUp, 
  ArrowDown, 
  ArrowLeft, 
  ArrowRight,
  CheckCircle2,
  RefreshCw
} from 'lucide-react';

interface LiveTelemetryModalProps {
  instrument: Instrument | null;
  onClose: () => void;
}

export const LiveTelemetryModal: React.FC<LiveTelemetryModalProps> = ({
  instrument,
  onClose
}) => {
  const [jogStepMm, setJogStepMm] = useState<number>(1.0);
  const [logs, setLogs] = useState<string[]>([]);
  const [livePressureData, setLivePressureData] = useState<number[]>([
    1013.2, 1013.1, 1012.9, 1010.5, 994.2, 982.0, 981.5, 982.2, 1011.0, 1013.2, 1013.3, 1013.0
  ]);

  useEffect(() => {
    if (!instrument) return;

    // Seed mock initial SiLA 2 logs
    setLogs([
      `[${new Date(Date.now() - 12000).toISOString()}] [SiLA2.Driver] Channel 1-8 initialization handshake: ACK`,
      `[${new Date(Date.now() - 8000).toISOString()}] [SiLA2.Sensor] Capacitive liquid level sensor (cLLD) reference baseline calibrated: 4.12 pF`,
      `[${new Date(Date.now() - 5000).toISOString()}] [SiLA2.Motion] Gantry position lock confirmed: X=120.45mm Y=84.10mm Z=12.00mm`,
      `[${new Date(Date.now() - 2000).toISOString()}] [SiLA2.Telemetry] Pressure transducer pLLD delta: -18.2 mbar (Liquid meniscus detected)`,
      `[${new Date().toISOString()}] [SiLA2.Orchestrator] Method step executing: ${instrument.activeProtocolName || 'Standard Cycle'}`
    ]);

    const interval = setInterval(() => {
      // Simulate live fluctuating pressure wave
      setLivePressureData(prev => {
        const next = [...prev.slice(1)];
        const lastVal = next[next.length - 1] || 1013.0;
        const drift = (Math.random() - 0.5) * 1.5;
        next.push(Number((1013.0 + (Math.sin(Date.now() / 1500) * 18) + drift).toFixed(1)));
        return next;
      });

      // Occasionally add a new log
      if (Math.random() > 0.6) {
        setLogs(prev => [
          ...prev.slice(-15),
          `[${new Date().toISOString()}] [SiLA2.Event] Packet verified: Deck temp ${instrument.telemetry.deckTempCelsius.toFixed(1)}°C · Syringe encoder: Nominal`
        ]);
      }
    }, 1200);

    return () => clearInterval(interval);
  }, [instrument]);

  if (!instrument) return null;

  // Build SVG path for live pressure chart
  const minP = 970;
  const maxP = 1040;
  const svgWidth = 500;
  const svgHeight = 120;
  const points = livePressureData.map((val, idx) => {
    const x = (idx / (livePressureData.length - 1)) * svgWidth;
    const y = svgHeight - ((val - minP) / (maxP - minP)) * svgHeight;
    return `${x},${y}`;
  }).join(' ');

  const handleJog = (axis: string, direction: number) => {
    const logEntry = `[${new Date().toISOString()}] [Manual.Jog] Axis ${axis} jogged by ${direction * jogStepMm} mm`;
    setLogs(prev => [...prev, logEntry]);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded bg-cyan-950/80 border border-cyan-800/80 flex items-center justify-center text-cyan-400">
              <Activity className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-slate-100 flex items-center gap-2">
                <span>{instrument.name}</span>
                <span className="text-xs font-mono text-cyan-400 font-normal">
                  ({instrument.model})
                </span>
              </h3>
              <div className="text-xs font-mono text-slate-400 flex items-center gap-2">
                <span>SiLA 2 Gateway v2.4</span>
                <span aria-hidden="true">·</span>
                <span className="text-emerald-400">Low-Latency Hardware Bus Connected</span>
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-200 rounded hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Pressure Liquid Level Sensing (pLLD) Waveform Chart */}
          <div className="bg-slate-950 border border-slate-800 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider font-mono">
                  Live Pressure Transducer Waveform (pLLD)
                </span>
              </div>
              <div className="text-xs font-mono text-slate-400">
                Current: <span className="text-cyan-300 font-bold tabular-nums">{livePressureData[livePressureData.length - 1]} mbar</span>
              </div>
            </div>

            {/* SVG Waveform Graphic */}
            <div className="relative w-full h-[120px] bg-slate-900/60 rounded border border-slate-800/80 overflow-hidden">
              {/* Horizontal Reference Grid lines */}
              <div className="absolute inset-0 flex flex-col justify-between pointer-events-none p-2 opacity-30">
                <div className="border-b border-dashed border-slate-600 text-[9px] font-mono text-slate-400">1040 mbar (Atmospheric + Peak)</div>
                <div className="border-b border-dashed border-slate-600 text-[9px] font-mono text-slate-400">1013 mbar (Standard Sea Level)</div>
                <div className="border-b border-dashed border-slate-600 text-[9px] font-mono text-slate-400">970 mbar (Aspiration Vacuum)</div>
              </div>

              <svg className="w-full h-full" viewBox={`0 0 ${svgWidth} ${svgHeight}`} preserveAspectRatio="none">
                <polyline
                  fill="none"
                  stroke="#06b6d4"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  points={points}
                />
              </svg>
            </div>
            <div className="text-[10px] font-mono text-slate-500 mt-2 flex justify-between">
              <span>T-15s (Aspiration Start)</span>
              <span className="text-cyan-400">● Meniscus Touch Recognized</span>
              <span>Live T-0s</span>
            </div>
          </div>

          {/* Hardware Manual Jog Controls & Calibration Diagnostic */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Axis Jogging */}
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-4">
              <div className="text-xs font-semibold text-slate-200 mb-2 flex items-center justify-between">
                <span>Manual Gantry Jog & Axis Calibration</span>
                <span className="text-[11px] font-mono text-slate-400">Step: {jogStepMm}mm</span>
              </div>

              {/* Step size selector */}
              <div className="flex gap-2 mb-3">
                {[0.1, 1.0, 10.0].map((s) => (
                  <button
                    key={s}
                    onClick={() => setJogStepMm(s)}
                    className={`px-2.5 py-1 text-[11px] font-mono rounded ${
                      jogStepMm === s ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50' : 'bg-slate-900 text-slate-400'
                    }`}
                  >
                    {s} mm
                  </button>
                ))}
              </div>

              {/* D-Pad Buttons */}
              <div className="flex flex-col items-center gap-1.5 py-2">
                <button
                  onClick={() => handleJog('Y', 1)}
                  className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-200 rounded border border-slate-700"
                  title="Y+ (Back)"
                >
                  <ArrowUp className="w-4 h-4" />
                </button>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleJog('X', -1)}
                    className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-200 rounded border border-slate-700"
                    title="X- (Left)"
                  >
                    <ArrowLeft className="w-4 h-4" />
                  </button>
                  <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-[10px] font-mono font-bold text-slate-400">
                    G
                  </div>
                  <button
                    onClick={() => handleJog('X', 1)}
                    className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-200 rounded border border-slate-700"
                    title="X+ (Right)"
                  >
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
                <button
                  onClick={() => handleJog('Y', -1)}
                  className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-200 rounded border border-slate-700"
                  title="Y- (Forward)"
                >
                  <ArrowDown className="w-4 h-4" />
                </button>
              </div>

              {/* Z-Axis Controls */}
              <div className="flex items-center justify-center gap-2 mt-2 pt-2 border-t border-slate-800">
                <button
                  onClick={() => handleJog('Z', 1)}
                  className="px-3 py-1 bg-slate-900 hover:bg-slate-800 text-slate-200 text-xs font-mono rounded border border-slate-700"
                >
                  Z+ (Retract Up)
                </button>
                <button
                  onClick={() => handleJog('Z', -1)}
                  className="px-3 py-1 bg-slate-900 hover:bg-slate-800 text-slate-200 text-xs font-mono rounded border border-slate-700"
                >
                  Z- (Plunge Down)
                </button>
              </div>
            </div>

            {/* Quick Diagnostics */}
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-3">
              <div className="text-xs font-semibold text-slate-200 mb-2">
                Subsystem Health Status
              </div>

              <div className="flex items-center justify-between text-xs font-mono text-slate-300">
                <span>CAN Bus Controller:</span>
                <span className="text-emerald-400 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> OK
                </span>
              </div>

              <div className="flex items-center justify-between text-xs font-mono text-slate-300">
                <span>Syringe Plunger Encoders:</span>
                <span className="text-emerald-400 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Synchronized
                </span>
              </div>

              <div className="flex items-center justify-between text-xs font-mono text-slate-300">
                <span>Waste Line Pressure:</span>
                <span className="text-slate-200 font-semibold">0.02 bar</span>
              </div>

              <div className="flex items-center justify-between text-xs font-mono text-slate-300">
                <span>Last Gravimetric Cal:</span>
                <span className="text-slate-400">{instrument.telemetry.lastCalibrationDate}</span>
              </div>

              <button
                onClick={() => {
                  setLogs(prev => [...prev, `[${new Date().toISOString()}] [Diag] Full automated syringe rinse cycle initialized... OK`]);
                }}
                className="w-full py-1.5 px-3 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded text-xs font-medium text-slate-200 flex items-center justify-center gap-1.5 transition-colors mt-2"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Execute Syringe Wash & De-bubble Routine</span>
              </button>
            </div>
          </div>

          {/* Real-time SiLA 2 / OPC UA Logs Stream */}
          <div className="bg-slate-950 border border-slate-800 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider font-mono">
                  SiLA 2 Command & Event Stream
                </span>
              </div>
              <span className="text-[10px] font-mono text-slate-500">Live Socket Active</span>
            </div>

            <div className="h-36 overflow-y-auto font-mono text-[11px] text-slate-300 bg-slate-900/80 p-2.5 rounded border border-slate-800/80 space-y-1">
              {logs.map((log, i) => (
                <div key={i} className="truncate">
                  {log}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-900/90 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded transition-colors"
          >
            Close Telemetry View
          </button>
        </div>
      </div>
    </div>
  );
};
