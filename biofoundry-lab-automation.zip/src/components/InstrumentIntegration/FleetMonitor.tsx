import React, { useState } from 'react';
import { Instrument } from '../../types/biotech';
import { 
  Cpu, 
  Play, 
  Pause, 
  AlertOctagon, 
  RotateCcw, 
  Lock, 
  Unlock, 
  Activity, 
  Thermometer, 
  Droplet, 
  Clock, 
  Wrench,
  CheckCircle2,
  AlertTriangle,
  Radio
} from 'lucide-react';

interface FleetMonitorProps {
  instruments: Instrument[];
  onTriggerAction: (instrumentId: string, action: 'pause' | 'resume' | 'estop' | 'home' | 'lock_toggle') => void;
  onSelectInstrument: (instrument: Instrument) => void;
}

export const FleetMonitor: React.FC<FleetMonitorProps> = ({
  instruments,
  onTriggerAction,
  onSelectInstrument
}) => {
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [doorLocked, setDoorLocked] = useState<Record<string, boolean>>({
    'inst-lh-01': true,
    'inst-lh-02': false,
    'inst-seq-01': true
  });

  const filtered = filterCategory === 'all' 
    ? instruments 
    : instruments.filter(i => i.category === filterCategory);

  const getStatusBadge = (status: Instrument['status']) => {
    switch (status) {
      case 'running':
        return (
          <div className="flex items-center gap-1.5 text-xs font-mono text-cyan-400">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
            <span className="font-semibold">RUNNING</span>
          </div>
        );
      case 'idle':
        return (
          <div className="flex items-center gap-1.5 text-xs font-mono text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span className="font-semibold">STANDBY / READY</span>
          </div>
        );
      case 'warning':
        return (
          <div className="flex items-center gap-1.5 text-xs font-mono text-amber-400">
            <span className="w-2 h-2 rounded-full bg-amber-400" />
            <span className="font-semibold">DRIFTING / WARN</span>
          </div>
        );
      case 'error':
        return (
          <div className="flex items-center gap-1.5 text-xs font-mono text-rose-400">
            <span className="w-2 h-2 rounded-full bg-rose-400" />
            <span className="font-semibold">FAULT / HALTED</span>
          </div>
        );
      default:
        return (
          <div className="flex items-center gap-1.5 text-xs font-mono text-slate-500">
            <span className="w-2 h-2 rounded-full bg-slate-500" />
            <span>OFFLINE</span>
          </div>
        );
    }
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Fleet Overview Telemetry Header */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">
            Connected Fleet
          </div>
          <div className="text-2xl font-bold font-mono text-slate-100 mt-1 tabular-nums">
            {instruments.length} <span className="text-xs font-normal text-slate-400">Units</span>
          </div>
          <div className="text-xs text-slate-400 mt-1 flex items-center gap-1.5">
            <Radio className="w-3.5 h-3.5 text-cyan-400" />
            <span>SiLA 2 Bus: 100% Operational</span>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">
            Active Runs
          </div>
          <div className="text-2xl font-bold font-mono text-cyan-400 mt-1 tabular-nums">
            {instruments.filter(i => i.status === 'running').length}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Across Liquid Handlers & Sequencers
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">
            Fleet Mean Deck Temp
          </div>
          <div className="text-2xl font-bold font-mono text-slate-100 mt-1 tabular-nums">
            22.4 <span className="text-xs font-normal text-slate-400">°C</span>
          </div>
          <div className="text-xs text-emerald-400 mt-1">
            Iso-thermal delta &lt; 0.6°C
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">
            Pipetting Calibration
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1 tabular-nums">
            99.92 <span className="text-xs font-normal text-slate-400">%</span>
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Gravimetric & pLLD verified
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1 bg-slate-900/70 p-1 rounded-lg border border-slate-800 self-start">
        {['all', 'liquid_handler', 'thermocycler', 'sequencer', 'plate_reader', 'colony_picker'].map((cat) => (
          <button
            key={cat}
            onClick={() => setFilterCategory(cat)}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              filterCategory === cat
                ? 'bg-slate-800 text-cyan-300 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {cat === 'all' ? 'All Instruments' : cat.replace('_', ' ').toUpperCase()}
          </button>
        ))}
      </div>

      {/* Instruments Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filtered.map((inst) => {
          const isDoorLocked = doorLocked[inst.id] ?? false;

          return (
            <div
              key={inst.id}
              className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 flex flex-col justify-between hover:border-slate-700 transition-all shadow-sm"
            >
              <div>
                {/* Header row */}
                <div className="flex items-start justify-between gap-3 border-b border-slate-800/80 pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-base font-semibold text-slate-100">
                        {inst.name}
                      </h4>
                      <span className="text-[11px] font-mono text-slate-400">
                        {inst.model}
                      </span>
                    </div>
                    <div className="text-xs text-slate-400 font-mono mt-0.5">
                      <span>Mfr: {inst.manufacturer}</span>
                      <span className="mx-2">·</span>
                      <span className="text-cyan-400">SiLA 2 Gateway</span>
                    </div>
                  </div>

                  <div>
                    {getStatusBadge(inst.status)}
                  </div>
                </div>

                {/* Active Run Progress */}
                {inst.status === 'running' && (
                  <div className="mt-4 p-3 bg-slate-950/70 border border-slate-800 rounded-lg">
                    <div className="flex items-center justify-between text-xs font-medium text-slate-200 mb-1.5">
                      <span className="truncate max-w-[260px] text-cyan-300">
                        {inst.activeProtocolName}
                      </span>
                      <span className="font-mono text-slate-400">
                        Step {inst.currentStepIndex} of {inst.totalSteps} ({inst.progressPercent}%)
                      </span>
                    </div>

                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden mb-2">
                      <div
                        className="bg-cyan-500 h-full rounded-full transition-all duration-500"
                        style={{ width: `${inst.progressPercent}%` }}
                      />
                    </div>

                    <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-slate-500" />
                        <span>Elapsed: {Math.floor(inst.elapsedSeconds / 60)}m</span>
                      </span>
                      <span>Est. Remaining: {Math.floor(inst.estimatedRemainingSeconds / 60)}m</span>
                    </div>
                  </div>
                )}

                {/* Telemetry Metrics Grid */}
                <div className="grid grid-cols-3 gap-3 my-4">
                  <div className="bg-slate-950/60 p-2.5 rounded border border-slate-800/80">
                    <div className="text-[10px] font-mono uppercase text-slate-500 flex items-center gap-1">
                      <Thermometer className="w-3 h-3 text-rose-400" />
                      <span>Deck Temp</span>
                    </div>
                    <div className="text-base font-semibold font-mono text-slate-200 mt-0.5 tabular-nums">
                      {inst.telemetry.deckTempCelsius.toFixed(1)} <span className="text-[10px] text-slate-400">°C</span>
                    </div>
                  </div>

                  <div className="bg-slate-950/60 p-2.5 rounded border border-slate-800/80">
                    <div className="text-[10px] font-mono uppercase text-slate-500 flex items-center gap-1">
                      <Activity className="w-3 h-3 text-cyan-400" />
                      <span>Pressure LLD</span>
                    </div>
                    <div className="text-base font-semibold font-mono text-slate-200 mt-0.5 tabular-nums">
                      {inst.telemetry.pressureLldMbar.toFixed(1)} <span className="text-[10px] text-slate-400">mbar</span>
                    </div>
                  </div>

                  <div className="bg-slate-950/60 p-2.5 rounded border border-slate-800/80">
                    <div className="text-[10px] font-mono uppercase text-slate-500 flex items-center gap-1">
                      <Droplet className="w-3 h-3 text-amber-400" />
                      <span>Waste Bin</span>
                    </div>
                    <div className="text-base font-semibold font-mono text-slate-200 mt-0.5 tabular-nums">
                      {inst.telemetry.wasteLevelPercent} <span className="text-[10px] text-slate-400">%</span>
                    </div>
                  </div>
                </div>

                {/* Channel Calibration Status for Liquid Handlers */}
                {inst.telemetry.pipetteChannelHealth.length > 0 && (
                  <div className="mb-4">
                    <div className="text-[10px] font-mono uppercase text-slate-500 mb-1.5 flex justify-between">
                      <span>8-Channel Pipette Core Calibration</span>
                      <span className="text-emerald-400">All Nominal</span>
                    </div>
                    <div className="flex gap-1">
                      {inst.telemetry.pipetteChannelHealth.map((health, idx) => (
                        <div
                          key={idx}
                          className="flex-1 py-1 rounded bg-slate-950 border border-slate-800 flex items-center justify-center text-[10px] font-mono font-bold text-emerald-400"
                          title={`Channel ${idx + 1}: ${health ? 'Calibrated' : 'Drift'}`}
                        >
                          CH{idx + 1}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Hardware Actions & Control Strip */}
              <div className="border-t border-slate-800 pt-3 flex flex-wrap items-center justify-between gap-2">
                <button
                  onClick={() => onSelectInstrument(inst)}
                  className="text-xs font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                >
                  <Activity className="w-3.5 h-3.5" />
                  <span>Inspect Live Telemetry & Log Stream</span>
                </button>

                <div className="flex items-center gap-1.5">
                  {/* Door Lock Toggle */}
                  <button
                    onClick={() => {
                      setDoorLocked(prev => ({ ...prev, [inst.id]: !isDoorLocked }));
                      onTriggerAction(inst.id, 'lock_toggle');
                    }}
                    className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs border border-slate-700 transition-colors"
                    title={isDoorLocked ? 'Deck Interlock: Locked' : 'Deck Interlock: Unlocked'}
                  >
                    {isDoorLocked ? <Lock className="w-3.5 h-3.5 text-amber-400" /> : <Unlock className="w-3.5 h-3.5 text-slate-400" />}
                  </button>

                  {/* Re-home Gantry */}
                  <button
                    onClick={() => onTriggerAction(inst.id, 'home')}
                    className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs border border-slate-700 transition-colors"
                    title="Home Robotic Axes (X/Y/Z)"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>

                  {/* Pause / Resume */}
                  {inst.status === 'running' ? (
                    <button
                      onClick={() => onTriggerAction(inst.id, 'pause')}
                      className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded hover:bg-amber-500/30 transition-colors"
                    >
                      <Pause className="w-3.5 h-3.5" />
                      <span>Pause</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => onTriggerAction(inst.id, 'resume')}
                      className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded hover:bg-emerald-500/30 transition-colors"
                    >
                      <Play className="w-3.5 h-3.5" />
                      <span>Resume</span>
                    </button>
                  )}

                  {/* Emergency Stop (E-Stop) */}
                  <button
                    onClick={() => onTriggerAction(inst.id, 'estop')}
                    className="flex items-center gap-1 px-2.5 py-1 text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/50 rounded hover:bg-rose-500/30 transition-colors"
                    title="Hardware E-Stop (Cut power to motors)"
                  >
                    <AlertOctagon className="w-3.5 h-3.5 text-rose-400" />
                    <span>E-STOP</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
