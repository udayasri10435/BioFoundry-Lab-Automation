import React, { useState } from 'react';
import { Microplate, WellSample } from '../../types/biotech';
import { 
  X, 
  Target, 
  Download, 
  Filter, 
  Check, 
  SlidersHorizontal,
  Table
} from 'lucide-react';

interface CherryPickModalProps {
  isOpen: boolean;
  onClose: () => void;
  plate: Microplate;
  onApplySelection: (selectedWellIds: string[]) => void;
}

export const CherryPickModal: React.FC<CherryPickModalProps> = ({
  isOpen,
  onClose,
  plate,
  onApplySelection
}) => {
  const [minConc, setMinConc] = useState<number>(30);
  const [minPurity, setMinPurity] = useState<number>(1.75);
  const [maxPurity, setMaxPurity] = useState<number>(2.00);
  const [onlyPassed, setOnlyPassed] = useState<boolean>(true);
  const [excludeControls, setExcludeControls] = useState<boolean>(true);
  const [transferVol, setTransferVol] = useState<number>(15.0);

  if (!isOpen) return null;

  // Evaluate matching wells
  const matchingWells: WellSample[] = Object.values(plate.wells).filter(well => {
    if (well.sampleType === 'empty') return false;
    if (excludeControls && (well.sampleType === 'neg_control' || well.sampleType === 'pos_control')) return false;
    if (onlyPassed && well.qcStatus !== 'passed') return false;
    if (well.concentrationNgUl < minConc) return false;
    if (well.purityA260A280 < minPurity || well.purityA260A280 > maxPurity) return false;
    return true;
  });

  const generateWorklistCSV = () => {
    const headers = ['Source_Plate', 'Source_Well', 'Sample_ID', 'Concentration_ng_ul', 'Transfer_Volume_ul', 'Dest_Plate', 'Dest_Well'];
    const rows = matchingWells.map((well, idx) => {
      // Map to destination well index (e.g. A1, A2...)
      const r = String.fromCharCode(65 + Math.floor(idx / 12));
      const c = (idx % 12) + 1;
      const destWell = `${r}${c}`;
      return [
        plate.barcode,
        well.wellId,
        well.sampleId || 'UNKNOWN',
        well.concentrationNgUl,
        transferVol,
        'PLT-96-CHERRYPICK-DEST',
        destWell
      ].join(',');
    });

    const csvContent = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `cherrypick_worklist_${plate.barcode}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleApply = () => {
    onApplySelection(matchingWells.map(w => w.wellId));
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-2xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div>
            <h3 className="text-base font-semibold text-slate-100 flex items-center gap-2">
              <Target className="w-4 h-4 text-cyan-400" />
              <span>Automated Cherry-Picking & Hit-Selection Planner</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Filter microplate wells by concentration thresholds to generate robotic transfer worklists.
            </p>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-200 rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Controls */}
        <div className="p-6 space-y-4 overflow-y-auto flex-1">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Min Concentration (ng/µL)
              </label>
              <input
                type="number"
                value={minConc}
                onChange={(e) => setMinConc(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs font-mono text-cyan-300"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Min Purity (A260/A280)
              </label>
              <input
                type="number"
                step="0.05"
                value={minPurity}
                onChange={(e) => setMinPurity(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs font-mono text-slate-200"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Max Purity (A260/A280)
              </label>
              <input
                type="number"
                step="0.05"
                value={maxPurity}
                onChange={(e) => setMaxPurity(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs font-mono text-slate-200"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="onlyPassed"
                checked={onlyPassed}
                onChange={(e) => setOnlyPassed(e.target.checked)}
                className="rounded border-slate-700 bg-slate-950 text-cyan-500"
              />
              <label htmlFor="onlyPassed" className="text-xs text-slate-300 cursor-pointer">
                Strict QC Passed Wells Only
              </label>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="excludeControls"
                checked={excludeControls}
                onChange={(e) => setExcludeControls(e.target.checked)}
                className="rounded border-slate-700 bg-slate-950 text-cyan-500"
              />
              <label htmlFor="excludeControls" className="text-xs text-slate-300 cursor-pointer">
                Exclude Control Blanks & Spikes
              </label>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Transfer Aliquot Volume (µL)
            </label>
            <input
              type="number"
              step="0.5"
              value={transferVol}
              onChange={(e) => setTransferVol(Number(e.target.value))}
              className="w-full max-w-[200px] bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs font-mono text-cyan-300"
            />
          </div>

          {/* Result Hit Count Summary */}
          <div className="p-4 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between">
            <div>
              <div className="text-[11px] font-mono text-slate-400 uppercase">
                Matching Cherry-Pick Hits
              </div>
              <div className="text-2xl font-bold font-mono text-cyan-400 mt-0.5 tabular-nums">
                {matchingWells.length} <span className="text-xs font-normal text-slate-400">of 96 wells</span>
              </div>
            </div>
            <div className="text-xs font-mono text-slate-400 text-right">
              Total Transfer Vol: <span className="text-slate-100 font-bold">{(matchingWells.length * transferVol).toFixed(1)} µL</span>
            </div>
          </div>

          {/* Quick Preview Matrix */}
          <div className="max-h-40 overflow-y-auto border border-slate-800 rounded bg-slate-950/70 p-2 font-mono text-[11px]">
            <div className="grid grid-cols-4 text-slate-500 border-b border-slate-800 pb-1 mb-1 font-semibold">
              <span>Well</span>
              <span>Sample ID</span>
              <span>Conc (ng/µL)</span>
              <span>A260/A280</span>
            </div>
            {matchingWells.map(w => (
              <div key={w.wellId} className="grid grid-cols-4 text-slate-300 py-0.5">
                <span className="text-cyan-400 font-bold">{w.wellId}</span>
                <span className="truncate">{w.sampleId}</span>
                <span>{w.concentrationNgUl}</span>
                <span>{w.purityA260A280}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-3 border-t border-slate-800 bg-slate-900/90">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs text-slate-400 hover:text-slate-200"
          >
            Cancel
          </button>

          <div className="flex items-center gap-3">
            <button
              onClick={generateWorklistCSV}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded border border-slate-700 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download CSV Worklist</span>
            </button>

            <button
              onClick={handleApply}
              className="flex items-center gap-1.5 px-4 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-semibold rounded transition-colors"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Select {matchingWells.length} Wells in Grid</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
