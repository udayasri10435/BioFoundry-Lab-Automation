import React, { useState } from 'react';
import { WellSample } from '../../types/biotech';
import { 
  Dna, 
  QrCode, 
  Printer, 
  Check, 
  AlertTriangle, 
  Copy, 
  GitFork, 
  FlaskConical 
} from 'lucide-react';

interface SampleInspectorProps {
  sample: WellSample | null;
  onUpdateSample?: (updated: WellSample) => void;
}

export const SampleInspector: React.FC<SampleInspectorProps> = ({
  sample,
  onUpdateSample
}) => {
  const [copied, setCopied] = useState(false);
  const [printSuccess, setPrintSuccess] = useState(false);

  if (!sample || sample.sampleType === 'empty') {
    return (
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-6 flex flex-col items-center justify-center text-center text-slate-500 h-full min-h-[360px]">
        <FlaskConical className="w-10 h-10 mb-2 stroke-1 text-slate-600" />
        <h4 className="text-sm font-medium text-slate-400">Empty Well or No Selection</h4>
        <p className="text-xs text-slate-500 max-w-xs mt-1">
          Click on any populated microplate well (A1–H12) to inspect molecular metrics, lineage tree, and 2D DataMatrix barcode.
        </p>
      </div>
    );
  }

  const handleCopyBarcode = () => {
    navigator.clipboard.writeText(sample.barcode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    setPrintSuccess(true);
    setTimeout(() => setPrintSuccess(false), 2500);
  };

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 flex flex-col gap-4">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <div className="text-[11px] font-mono text-cyan-400 uppercase tracking-wider">
            Well Coordinate: {sample.wellId}
          </div>
          <h3 className="text-base font-semibold text-slate-100 flex items-center gap-2">
            <span>{sample.sampleName || 'Sample Details'}</span>
          </h3>
        </div>

        {/* QC Status Tag */}
        <div>
          {sample.qcStatus === 'passed' && (
            <span className="text-xs font-mono font-semibold text-emerald-400 bg-emerald-950/80 border border-emerald-800/80 px-2 py-0.5 rounded">
              QC PASSED
            </span>
          )}
          {sample.qcStatus === 'warning' && (
            <span className="text-xs font-mono font-semibold text-amber-400 bg-amber-950/80 border border-amber-800/80 px-2 py-0.5 rounded flex items-center gap-1">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>QC WARN</span>
            </span>
          )}
          {sample.qcStatus === 'failed' && (
            <span className="text-xs font-mono font-semibold text-rose-400 bg-rose-950/80 border border-rose-800/80 px-2 py-0.5 rounded">
              QC FAILED
            </span>
          )}
        </div>
      </div>

      {/* Primary Metrics (Concentration, Purity, Volume) */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
          <div className="text-[10px] font-mono text-slate-400 uppercase">
            Concentration
          </div>
          <div className="text-xl font-bold font-mono text-cyan-300 mt-0.5 tabular-nums">
            {sample.concentrationNgUl}
          </div>
          <div className="text-[10px] font-mono text-slate-500">ng/µL (PicoGreen)</div>
        </div>

        <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
          <div className="text-[10px] font-mono text-slate-400 uppercase">
            A260 / A280 Purity
          </div>
          <div className="text-xl font-bold font-mono text-slate-100 mt-0.5 tabular-nums">
            {sample.purityA260A280}
          </div>
          <div className="text-[10px] font-mono text-slate-500">Target: 1.80–2.00</div>
        </div>

        <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
          <div className="text-[10px] font-mono text-slate-400 uppercase">
            Remaining Vol
          </div>
          <div className="text-xl font-bold font-mono text-slate-100 mt-0.5 tabular-nums">
            {sample.volumeMicroLitres}
          </div>
          <div className="text-[10px] font-mono text-slate-500">µL (Max 200 µL)</div>
        </div>
      </div>

      {/* Biological Specimen & Genetic Construct Meta */}
      <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-lg space-y-2 text-xs">
        <div className="text-[11px] font-mono text-slate-400 uppercase">
          Biological Construct Metadata
        </div>
        <div className="flex justify-between font-mono text-slate-300">
          <span>Organism / Vector:</span>
          <span className="text-slate-100 font-semibold">{sample.organismOrConstruct || 'Unspecified'}</span>
        </div>
        <div className="flex justify-between font-mono text-slate-300">
          <span>Sample Modality:</span>
          <span className="text-cyan-300 uppercase">{sample.sampleType}</span>
        </div>
        <div className="flex justify-between font-mono text-slate-300">
          <span>Freeze-Thaw Log:</span>
          <span className={sample.freezeThawCycles >= 3 ? 'text-amber-400' : 'text-slate-200'}>
            {sample.freezeThawCycles} cycle(s)
          </span>
        </div>
      </div>

      {/* Specimen Lineage Tree */}
      <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-lg space-y-2 text-xs">
        <div className="text-[11px] font-mono text-slate-400 uppercase flex items-center gap-1.5">
          <GitFork className="w-3.5 h-3.5 text-cyan-400" />
          <span>Specimen Chain of Custody & Lineage</span>
        </div>

        <div className="flex flex-col gap-1.5 font-mono text-[11px] pl-2 border-l border-slate-700">
          <div className="flex items-center justify-between text-slate-400">
            <span>Parent Matrix Tube:</span>
            <span className="text-slate-200">{sample.parentTubeBarcode || 'TUBE-2026-PRIMARY'}</span>
          </div>
          <div className="flex items-center justify-between text-cyan-300 font-semibold">
            <span>Current Working Aliquot:</span>
            <span>Well {sample.wellId} ({sample.barcode})</span>
          </div>
          <div className="flex items-center justify-between text-slate-500">
            <span>Downstream Destination:</span>
            <span>Illumina NovaSeq X Flow Cell 25B</span>
          </div>
        </div>
      </div>

      {/* 2D DataMatrix Barcode & Label Print Strip */}
      <div className="bg-slate-950 border border-slate-800 p-3 rounded-lg flex items-center justify-between gap-4">
        {/* Visual 2D DataMatrix Grid Simulation */}
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-white p-1 rounded flex flex-col justify-between shadow">
            {/* 2D DataMatrix square representation */}
            <div className="grid grid-cols-5 gap-0.5 w-full h-full">
              {Array.from({ length: 25 }).map((_, i) => (
                <div
                  key={i}
                  className={`${(i % 2 === 0 || i % 3 === 0) ? 'bg-black' : 'bg-white'} w-full h-full`}
                />
              ))}
            </div>
          </div>

          <div>
            <div className="text-[11px] font-mono text-slate-400">LIMS Barcode Token</div>
            <div className="text-xs font-mono font-bold text-slate-200 truncate max-w-[160px]">
              {sample.barcode}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyBarcode}
            className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 rounded transition-colors"
            title="Copy Barcode"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-medium rounded transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>{printSuccess ? 'Label Sent!' : 'Print 2D Label'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
