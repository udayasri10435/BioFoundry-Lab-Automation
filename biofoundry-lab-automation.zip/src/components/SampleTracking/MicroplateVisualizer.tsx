import React, { useState } from 'react';
import { Microplate, WellSample } from '../../types/biotech';
import { SampleInspector } from './SampleInspector';
import { CherryPickModal } from './CherryPickModal';
import { 
  Grid, 
  Target, 
  Download, 
  BarChart3, 
  Layers, 
  Sparkles,
  Info,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';

interface MicroplateVisualizerProps {
  plate: Microplate;
  onUpdatePlate: (updated: Microplate) => void;
}

export type HeatmapMode = 'concentration' | 'purity' | 'volume' | 'sample_type' | 'qc_status';

export const MicroplateVisualizer: React.FC<MicroplateVisualizerProps> = ({
  plate,
  onUpdatePlate
}) => {
  const [heatmapMode, setHeatmapMode] = useState<HeatmapMode>('concentration');
  const [selectedWellId, setSelectedWellId] = useState<string>('A1');
  const [selectedWellSet, setSelectedWellSet] = useState<Set<string>>(new Set(['A1']));
  const [isCherryPickOpen, setIsCherryPickOpen] = useState(false);

  const rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
  const columns = Array.from({ length: 12 }, (_, i) => i + 1);

  const selectedSample = plate.wells[selectedWellId] || null;

  // Calculate Plate Analytics
  const populatedWells = Object.values(plate.wells).filter(w => w.sampleType !== 'empty');
  const totalVolume = populatedWells.reduce((acc, w) => acc + w.volumeMicroLitres, 0);
  const meanConc = populatedWells.length > 0 
    ? (populatedWells.reduce((acc, w) => acc + w.concentrationNgUl, 0) / populatedWells.length).toFixed(1)
    : '0';
  const meanPurity = populatedWells.length > 0
    ? (populatedWells.reduce((acc, w) => acc + w.purityA260A280, 0) / populatedWells.length).toFixed(2)
    : '0';
  const passedCount = populatedWells.filter(w => w.qcStatus === 'passed').length;
  const passRate = populatedWells.length > 0 
    ? ((passedCount / populatedWells.length) * 100).toFixed(1)
    : '0';

  // Heatmap Color Calculator
  const getWellColor = (well: WellSample) => {
    if (well.sampleType === 'empty') return 'bg-slate-950 border-slate-800 text-slate-700';

    if (heatmapMode === 'concentration') {
      const conc = well.concentrationNgUl;
      if (conc >= 55) return 'bg-cyan-400 text-slate-950 font-bold border-cyan-300 shadow-sm shadow-cyan-500/30';
      if (conc >= 40) return 'bg-cyan-600 text-slate-100 border-cyan-500';
      if (conc >= 25) return 'bg-cyan-800 text-cyan-100 border-cyan-700';
      if (conc >= 10) return 'bg-cyan-950 text-cyan-300 border-cyan-900';
      return 'bg-slate-900 text-slate-400 border-slate-800';
    }

    if (heatmapMode === 'purity') {
      const p = well.purityA260A280;
      if (p >= 1.80 && p <= 2.00) return 'bg-emerald-600 text-emerald-100 border-emerald-500';
      if ((p >= 1.70 && p < 1.80) || (p > 2.00 && p <= 2.10)) return 'bg-amber-600 text-amber-100 border-amber-500';
      return 'bg-rose-700 text-rose-100 border-rose-600';
    }

    if (heatmapMode === 'volume') {
      const vol = well.volumeMicroLitres;
      if (vol >= 40) return 'bg-blue-500 text-slate-950 border-blue-400 font-bold';
      if (vol >= 25) return 'bg-blue-700 text-blue-100 border-blue-600';
      return 'bg-blue-950 text-blue-300 border-blue-900';
    }

    if (heatmapMode === 'sample_type') {
      switch (well.sampleType) {
        case 'gDNA': return 'bg-teal-700 text-teal-100 border-teal-600';
        case 'cDNA': return 'bg-indigo-700 text-indigo-100 border-indigo-600';
        case 'plasmid': return 'bg-purple-700 text-purple-100 border-purple-600';
        case 'pos_control': return 'bg-emerald-500 text-slate-950 font-bold border-emerald-400';
        case 'neg_control': return 'bg-slate-800 text-slate-400 border-slate-700';
        default: return 'bg-slate-900 text-slate-300 border-slate-800';
      }
    }

    if (heatmapMode === 'qc_status') {
      switch (well.qcStatus) {
        case 'passed': return 'bg-emerald-600 text-emerald-100 border-emerald-500';
        case 'warning': return 'bg-amber-600 text-amber-100 border-amber-500';
        case 'failed': return 'bg-rose-600 text-rose-100 border-rose-500';
        default: return 'bg-slate-900 text-slate-500 border-slate-800';
      }
    }

    return 'bg-slate-900 text-slate-300 border-slate-800';
  };

  const handleSelectRow = (r: string) => {
    const rowWells = columns.map(c => `${r}${c}`);
    setSelectedWellSet(new Set(rowWells));
    setSelectedWellId(`${r}1`);
  };

  const handleSelectCol = (c: number) => {
    const colWells = rows.map(r => `${r}${c}`);
    setSelectedWellSet(new Set(colWells));
    setSelectedWellId(`A${c}`);
  };

  const handleWellClick = (wId: string, e: React.MouseEvent) => {
    if (e.shiftKey || e.metaKey) {
      const next = new Set(selectedWellSet);
      if (next.has(wId)) next.delete(wId);
      else next.add(wId);
      setSelectedWellSet(next);
    } else {
      setSelectedWellSet(new Set([wId]));
    }
    setSelectedWellId(wId);
  };

  const handleExportPlateCSV = () => {
    const headers = ['Well', 'Sample_ID', 'Sample_Type', 'Concentration_ng_ul', 'Purity_A260_A280', 'Volume_ul', 'QC_Status', 'Barcode'];
    const rowsArr = Object.values(plate.wells).map(w => [
      w.wellId,
      w.sampleId || 'EMPTY',
      w.sampleType,
      w.concentrationNgUl,
      w.purityA260A280,
      w.volumeMicroLitres,
      w.qcStatus,
      w.barcode
    ].join(','));

    const csv = [headers.join(','), ...rowsArr].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `microplate_manifest_${plate.barcode}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Plate Header Analytics Ribbon */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">
            Total Populated Wells
          </div>
          <div className="text-2xl font-bold font-mono text-slate-100 mt-1 tabular-nums">
            {populatedWells.length} <span className="text-xs font-normal text-slate-400">/ 96 positions</span>
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Barcode: <span className="font-mono text-cyan-300 font-semibold">{plate.barcode}</span>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">
            Mean Yield (Conc)
          </div>
          <div className="text-2xl font-bold font-mono text-cyan-400 mt-1 tabular-nums">
            {meanConc} <span className="text-xs font-normal text-slate-400">ng/µL</span>
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Total Liquid Vol: {totalVolume.toFixed(0)} µL
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">
            Mean A260 / A280 Purity
          </div>
          <div className="text-2xl font-bold font-mono text-slate-100 mt-1 tabular-nums">
            {meanPurity}
          </div>
          <div className="text-xs text-emerald-400 mt-1">
            Spectrophotometric Spec: Nominal
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">
            QC Compliance Rate
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1 tabular-nums">
            {passRate} <span className="text-xs font-normal text-slate-400">%</span>
          </div>
          <div className="text-xs text-slate-400 mt-1">
            {passedCount} passed / {populatedWells.length - passedCount} flagged
          </div>
        </div>
      </div>

      {/* Control Bar: Heatmap Selector & Cherry-Picking Action */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-3 rounded-lg">
        {/* Heatmap Mode Selector */}
        <div className="flex items-center gap-1.5 overflow-x-auto">
          <span className="text-xs font-mono uppercase text-slate-400 mr-1.5 hidden sm:inline">
            Heatmap Layer:
          </span>
          {[
            { id: 'concentration', label: 'Concentration (ng/µL)' },
            { id: 'purity', label: 'A260/A280 Purity' },
            { id: 'volume', label: 'Volume (µL)' },
            { id: 'sample_type', label: 'Sample Modality' },
            { id: 'qc_status', label: 'QC Assessment' }
          ].map((mode) => (
            <button
              key={mode.id}
              onClick={() => setHeatmapMode(mode.id as HeatmapMode)}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                heatmapMode === mode.id
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {mode.label}
            </button>
          ))}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsCherryPickOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded border border-slate-700 transition-colors"
          >
            <Target className="w-3.5 h-3.5 text-cyan-400" />
            <span>Hit / Cherry Picking</span>
          </button>

          <button
            onClick={handleExportPlateCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded border border-slate-700 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Plate CSV</span>
          </button>
        </div>
      </div>

      {/* Main Grid & Sample Inspector Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* 96-Well Microplate Matrix (Cols 1-8) */}
        <div className="lg:col-span-8 bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
                <Grid className="w-4 h-4 text-cyan-400" />
                <span>{plate.name}</span>
              </h3>
              <div className="text-xs font-mono text-slate-400 mt-0.5">
                ANSI/SLAS Standard 96-Well Matrix · Click headers to multi-select columns/rows
              </div>
            </div>

            {/* Selected well count badge */}
            <div className="text-xs font-mono text-cyan-400 bg-cyan-950/80 border border-cyan-800/80 px-2 py-0.5 rounded">
              {selectedWellSet.size} Well(s) Selected
            </div>
          </div>

          {/* Microplate Visual Representation */}
          <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 overflow-x-auto">
            {/* Column Headers (1 to 12) */}
            <div className="grid grid-cols-13 gap-1.5 mb-1.5 text-center font-mono text-xs text-slate-400 font-semibold min-w-[500px]">
              <div className="w-7 h-7 flex items-center justify-center text-[10px] text-slate-600">
                POS
              </div>
              {columns.map((c) => (
                <button
                  key={c}
                  onClick={() => handleSelectCol(c)}
                  className="w-full h-7 rounded hover:bg-slate-800 text-slate-400 hover:text-cyan-300 flex items-center justify-center transition-colors"
                  title={`Select Column ${c}`}
                >
                  {c}
                </button>
              ))}
            </div>

            {/* Matrix Rows (A to H) */}
            <div className="space-y-1.5 min-w-[500px]">
              {rows.map((row) => (
                <div key={row} className="grid grid-cols-13 gap-1.5 items-center">
                  {/* Row Letter Header */}
                  <button
                    onClick={() => handleSelectRow(row)}
                    className="w-7 h-7 rounded hover:bg-slate-800 text-slate-400 hover:text-cyan-300 font-mono text-xs font-semibold flex items-center justify-center transition-colors"
                    title={`Select Row ${row}`}
                  >
                    {row}
                  </button>

                  {/* 12 Wells */}
                  {columns.map((col) => {
                    const wellId = `${row}${col}`;
                    const well = plate.wells[wellId];
                    const isSelected = selectedWellSet.has(wellId);
                    const colorClasses = getWellColor(well);

                    return (
                      <button
                        key={wellId}
                        onClick={(e) => handleWellClick(wellId, e)}
                        className={`aspect-square rounded-full border transition-all flex items-center justify-center text-[10px] font-mono select-none relative group ${colorClasses} ${
                          isSelected
                            ? 'ring-2 ring-white scale-110 z-10'
                            : 'hover:scale-105 hover:border-white/60'
                        }`}
                        title={`${wellId}: ${well.sampleName || 'Empty'} (${well.concentrationNgUl} ng/µL)`}
                      >
                        {/* Well Label */}
                        <span className="opacity-70 group-hover:opacity-100">
                          {col}
                        </span>

                        {/* Miniature QC dot for warnings */}
                        {well.qcStatus === 'warning' && (
                          <div className="absolute top-0 right-0 w-1.5 h-1.5 rounded-full bg-amber-400 ring-1 ring-slate-950" />
                        )}
                        {well.qcStatus === 'failed' && (
                          <div className="absolute top-0 right-0 w-1.5 h-1.5 rounded-full bg-rose-400 ring-1 ring-slate-950" />
                        )}
                      </button>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>

          {/* Heatmap Legend */}
          <div className="mt-4 pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between text-xs font-mono text-slate-400 gap-3">
            <div className="flex items-center gap-3">
              <span>Legend:</span>
              {heatmapMode === 'concentration' && (
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-slate-900 border border-slate-700" /> &lt;10
                  <div className="w-3 h-3 rounded-full bg-cyan-950 border border-cyan-900" /> 10–25
                  <div className="w-3 h-3 rounded-full bg-cyan-800 border border-cyan-700" /> 25–40
                  <div className="w-3 h-3 rounded-full bg-cyan-600 border border-cyan-500" /> 40–55
                  <div className="w-3 h-3 rounded-full bg-cyan-400 border border-cyan-300" /> &gt;55 ng/µL
                </div>
              )}
              {heatmapMode === 'purity' && (
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-emerald-600" /> 1.80–2.00 (Ideal)
                  <div className="w-3 h-3 rounded-full bg-amber-600" /> 1.70–1.80 (Borderline)
                  <div className="w-3 h-3 rounded-full bg-rose-600" /> &lt;1.70 (Contaminated)
                </div>
              )}
              {heatmapMode === 'qc_status' && (
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-emerald-600" /> QC Passed
                  <div className="w-3 h-3 rounded-full bg-amber-600" /> QC Warning
                  <div className="w-3 h-3 rounded-full bg-rose-600" /> QC Failed
                </div>
              )}
            </div>

            <div className="text-slate-500">
              Shift+Click to multi-select individual wells
            </div>
          </div>
        </div>

        {/* Sample Inspector Panel (Cols 9-12) */}
        <div className="lg:col-span-4">
          <SampleInspector sample={selectedSample} />
        </div>
      </div>

      {/* Cherry Picking Modal */}
      <CherryPickModal
        isOpen={isCherryPickOpen}
        onClose={() => setIsCherryPickOpen(false)}
        plate={plate}
        onApplySelection={(selectedIds) => {
          setSelectedWellSet(new Set(selectedIds));
          if (selectedIds[0]) setSelectedWellId(selectedIds[0]);
        }}
      />
    </div>
  );
};
