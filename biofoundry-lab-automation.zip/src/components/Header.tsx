import React from 'react';
import { IndustryProfile } from '../types/biotech';
import { 
  Play, 
  RotateCcw, 
  Download, 
  Layers, 
  Cpu, 
  FileText, 
  Grid, 
  Database,
  CheckCircle2
} from 'lucide-react';

interface HeaderProps {
  currentTab: 'protocol' | 'instruments' | 'lims' | 'samples' | 'reagents';
  onSelectTab: (tab: 'protocol' | 'instruments' | 'lims' | 'samples' | 'reagents') => void;
  activeProfile: IndustryProfile;
  onChangeProfile: (profile: IndustryProfile) => void;
  isSimulating: boolean;
  onToggleSimulation: () => void;
  onOpenExportModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onSelectTab,
  activeProfile,
  onChangeProfile,
  isSimulating,
  onToggleSimulation,
  onOpenExportModal
}) => {
  return (
    <header className="border-b border-slate-800 bg-slate-950/90 backdrop-blur sticky top-0 z-40">
      {/* 3-Zone Top Navigation Contract */}
      <div className="w-full px-6 py-3 flex items-center justify-between">
        {/* Zone 1: Single Wordmark */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-cyan-950 border border-cyan-800/80 flex items-center justify-center text-cyan-400 font-mono font-bold text-sm">
            BF
          </div>
          <div>
            <span className="text-base font-semibold tracking-tight text-slate-100">
              BioFoundry OS
            </span>
            <div className="text-xs text-slate-400 font-mono hidden sm:flex items-center gap-1.5">
              <span>SiLA 2 Core</span>
              <span aria-hidden="true">·</span>
              <span>21 CFR Part 11</span>
            </div>
          </div>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 bg-slate-900/90 p-1 rounded-lg border border-slate-800">
          <button
            onClick={() => onSelectTab('protocol')}
            className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              currentTab === 'protocol'
                ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Protocol Designer</span>
          </button>

          <button
            onClick={() => onSelectTab('instruments')}
            className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              currentTab === 'instruments'
                ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>Deck & Fleet</span>
          </button>

          <button
            onClick={() => onSelectTab('lims')}
            className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              currentTab === 'lims'
                ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>LIMS & Work Orders</span>
          </button>

          <button
            onClick={() => onSelectTab('samples')}
            className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              currentTab === 'samples'
                ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Grid className="w-3.5 h-3.5" />
            <span>Microplate Tracking</span>
          </button>

          <button
            onClick={() => onSelectTab('reagents')}
            className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              currentTab === 'reagents'
                ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>Reagent Inventory</span>
          </button>
        </nav>

        {/* Zone 3: Industry Profile & Primary Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Profile Switcher */}
          <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 rounded px-2.5 py-1">
            <span className="text-[11px] uppercase tracking-wider text-slate-400 font-mono hidden md:inline">
              Domain:
            </span>
            <select
              value={activeProfile}
              onChange={(e) => onChangeProfile(e.target.value as IndustryProfile)}
              className="bg-transparent text-xs font-medium text-slate-200 focus:outline-none cursor-pointer"
            >
              <option value="genomics" className="bg-slate-900 text-slate-200">
                Genomics Core Lab (WGS / RNA)
              </option>
              <option value="synbio" className="bg-slate-900 text-slate-200">
                Synthetic Biology Foundry
              </option>
              <option value="cro" className="bg-slate-900 text-slate-200">
                CRO / Preclinical ADME
              </option>
            </select>
          </div>

          {/* Action 1: Export Scripts */}
          <button
            onClick={onOpenExportModal}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-700/80 rounded transition-colors whitespace-nowrap"
            title="Export to Python, Venus, SiLA 2"
          >
            <Download className="w-3.5 h-3.5 text-slate-400" />
            <span className="hidden sm:inline">Export Script</span>
          </button>

          {/* Action 2: Run / Simulate */}
          <button
            onClick={onToggleSimulation}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded transition-all whitespace-nowrap ${
              isSimulating
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50 hover:bg-amber-500/30'
                : 'bg-cyan-500 text-slate-950 hover:bg-cyan-400 font-semibold shadow-sm'
            }`}
          >
            {isSimulating ? (
              <>
                <RotateCcw className="w-3.5 h-3.5 animate-spin" />
                <span>Simulating...</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Run Protocol</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Mobile Tab Strip */}
      <div className="lg:hidden flex items-center overflow-x-auto px-4 py-2 gap-2 border-t border-slate-800/80 bg-slate-950">
        <button
          onClick={() => onSelectTab('protocol')}
          className={`px-3 py-1 text-xs rounded whitespace-nowrap ${
            currentTab === 'protocol' ? 'bg-cyan-500/20 text-cyan-300 font-medium' : 'text-slate-400'
          }`}
        >
          Protocol Designer
        </button>
        <button
          onClick={() => onSelectTab('instruments')}
          className={`px-3 py-1 text-xs rounded whitespace-nowrap ${
            currentTab === 'instruments' ? 'bg-cyan-500/20 text-cyan-300 font-medium' : 'text-slate-400'
          }`}
        >
          Fleet & Deck
        </button>
        <button
          onClick={() => onSelectTab('lims')}
          className={`px-3 py-1 text-xs rounded whitespace-nowrap ${
            currentTab === 'lims' ? 'bg-cyan-500/20 text-cyan-300 font-medium' : 'text-slate-400'
          }`}
        >
          LIMS & Orders
        </button>
        <button
          onClick={() => onSelectTab('samples')}
          className={`px-3 py-1 text-xs rounded whitespace-nowrap ${
            currentTab === 'samples' ? 'bg-cyan-500/20 text-cyan-300 font-medium' : 'text-slate-400'
          }`}
        >
          Microplates
        </button>
        <button
          onClick={() => onSelectTab('reagents')}
          className={`px-3 py-1 text-xs rounded whitespace-nowrap ${
            currentTab === 'reagents' ? 'bg-cyan-500/20 text-cyan-300 font-medium' : 'text-slate-400'
          }`}
        >
          Reagents
        </button>
      </div>
    </header>
  );
};
