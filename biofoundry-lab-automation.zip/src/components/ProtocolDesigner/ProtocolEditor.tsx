import React, { useState } from 'react';
import { ProtocolStep, StepType, DeckSlot, LabwareType } from '../../types/biotech';
import { DeckLayoutView } from './DeckLayoutView';
import { StepConfigPanel } from './StepConfigPanel';
import { 
  Plus, 
  ChevronUp, 
  ChevronDown, 
  Copy, 
  Trash2, 
  AlertTriangle, 
  CheckCircle2, 
  Pipette, 
  Flame, 
  Magnet, 
  RotateCw, 
  Disc, 
  Eye, 
  Scan,
  Clock,
  Layers
} from 'lucide-react';

interface ProtocolEditorProps {
  steps: ProtocolStep[];
  onUpdateSteps: (steps: ProtocolStep[]) => void;
  deckSlots: DeckSlot[];
  onUpdateSlot: (slotNumber: number, labwareType: LabwareType | null, name: string) => void;
  isSimulating: boolean;
  simulationStepIndex: number;
  simulationGantryX: number;
  simulationGantryY: number;
  simulationStatusText: string;
}

export const ProtocolEditor: React.FC<ProtocolEditorProps> = ({
  steps,
  onUpdateSteps,
  deckSlots,
  onUpdateSlot,
  isSimulating,
  simulationStepIndex,
  simulationGantryX,
  simulationGantryY,
  simulationStatusText
}) => {
  const [selectedStepId, setSelectedStepId] = useState<string>(steps[0]?.id || '');
  const [showAddMenu, setShowAddMenu] = useState(false);

  const selectedStep = steps.find(s => s.id === selectedStepId) || null;

  // Calculate total runtime in minutes
  const totalSeconds = steps.reduce((acc, s) => acc + s.durationSeconds, 0);
  const totalMinutes = (totalSeconds / 60).toFixed(1);

  // Validation rules engine
  const validationWarnings: string[] = [];
  steps.forEach((step, idx) => {
    if (step.type === 'pipette_transfer' || step.type === 'multichannel_transfer') {
      const sSlot = step.parameters.sourceSlot;
      const dSlot = step.parameters.destinationSlot;
      const sObj = deckSlots.find(d => d.slotNumber === sSlot);
      const dObj = deckSlots.find(d => d.slotNumber === dSlot);

      if (sSlot && (!sObj || !sObj.isOccupied)) {
        validationWarnings.push(`Step ${idx + 1} (${step.name}): Source Deck Slot ${sSlot} is empty.`);
      }
      if (dSlot && (!dObj || !dObj.isOccupied)) {
        validationWarnings.push(`Step ${idx + 1} (${step.name}): Destination Deck Slot ${dSlot} is empty.`);
      }
      if ((step.parameters.volumeMicroLitres || 0) > 200 && dObj?.labwareType === 'plate_96_pcr') {
        validationWarnings.push(`Step ${idx + 1}: Volume exceeds standard PCR plate well capacity (200 µL).`);
      }
    }
  });

  const handleAddStep = (type: StepType) => {
    const newStepId = `step-${Date.now()}`;
    let newStep: ProtocolStep = {
      id: newStepId,
      name: `New ${type.replace('_', ' ')}`,
      type,
      description: 'Configured automated action',
      durationSeconds: 120,
      parameters: {}
    };

    if (type === 'pipette_transfer') {
      newStep.name = 'Liquid Aspirate & Dispense';
      newStep.parameters = {
        sourceSlot: 4,
        destinationSlot: 5,
        volumeMicroLitres: 20,
        liquidClass: 'water',
        tipHandling: 'new_tip_always',
        mixCycles: 3,
        touchTip: true
      };
    } else if (type === 'thermocycle') {
      newStep.name = 'PCR Amplification Stage';
      newStep.durationSeconds = 1800;
      newStep.parameters = {
        lidTemperatureCelsius: 105,
        stages: [
          {
            name: 'Denaturation & Annealing',
            cycles: 30,
            steps: [
              { temperatureCelsius: 98, holdTimeSeconds: 15 },
              { temperatureCelsius: 60, holdTimeSeconds: 30 },
              { temperatureCelsius: 72, holdTimeSeconds: 45 }
            ]
          }
        ]
      };
    } else if (type === 'magnetic_bead') {
      newStep.name = 'Bead Separation & Ethanol Wash';
      newStep.durationSeconds = 600;
      newStep.parameters = {
        bindingTimeMinutes: 5,
        magnetEngageHeightMm: 12,
        washCycles: 2,
        ethanolPercentage: 80,
        elutionVolumeMicroLitres: 20
      };
    } else if (type === 'incubate_shake') {
      newStep.name = 'Thermal Agitation Outgrowth';
      newStep.durationSeconds = 600;
      newStep.parameters = {
        temperatureCelsius: 37,
        shakeRpm: 800,
        shakeDurationMinutes: 10
      };
    } else if (type === 'plate_reader') {
      newStep.name = 'OD600 Absorbance Kinetic Read';
      newStep.durationSeconds = 90;
      newStep.parameters = {
        readMode: 'absorbance',
        wavelengthNm: 600
      };
    }

    const updated = [...steps, newStep];
    onUpdateSteps(updated);
    setSelectedStepId(newStepId);
    setShowAddMenu(false);
  };

  const handleMoveStep = (idx: number, direction: 'up' | 'down') => {
    if (direction === 'up' && idx === 0) return;
    if (direction === 'down' && idx === steps.length - 1) return;
    const targetIdx = direction === 'up' ? idx - 1 : idx + 1;
    const updated = [...steps];
    const temp = updated[idx];
    updated[idx] = updated[targetIdx];
    updated[targetIdx] = temp;
    onUpdateSteps(updated);
  };

  const handleDuplicateStep = (idx: number) => {
    const item = steps[idx];
    const duplicated: ProtocolStep = {
      ...item,
      id: `step-${Date.now()}`,
      name: `${item.name} (Copy)`
    };
    const updated = [...steps];
    updated.splice(idx + 1, 0, duplicated);
    onUpdateSteps(updated);
  };

  const handleDeleteStep = (id: string) => {
    const updated = steps.filter(s => s.id !== id);
    onUpdateSteps(updated);
    if (selectedStepId === id && updated.length > 0) {
      setSelectedStepId(updated[0].id);
    }
  };

  const handleUpdateStep = (updatedStep: ProtocolStep) => {
    const updated = steps.map(s => s.id === updatedStep.id ? updatedStep : s);
    onUpdateSteps(updated);
  };

  const getStepIcon = (type: StepType) => {
    switch (type) {
      case 'pipette_transfer':
      case 'multichannel_transfer':
        return <Pipette className="w-4 h-4 text-cyan-400" />;
      case 'thermocycle':
        return <Flame className="w-4 h-4 text-rose-400" />;
      case 'magnetic_bead':
        return <Magnet className="w-4 h-4 text-indigo-400" />;
      case 'incubate_shake':
        return <RotateCw className="w-4 h-4 text-emerald-400" />;
      case 'centrifuge':
        return <Disc className="w-4 h-4 text-amber-400" />;
      case 'plate_reader':
        return <Eye className="w-4 h-4 text-blue-400" />;
      case 'colony_pick':
        return <Scan className="w-4 h-4 text-teal-400" />;
    }
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Deck Layout Visualization Stage */}
      <DeckLayoutView
        deckSlots={deckSlots}
        onUpdateSlot={onUpdateSlot}
        activeStepSourceSlot={selectedStep?.parameters.sourceSlot}
        activeStepDestSlot={selectedStep?.parameters.destinationSlot}
        isSimulating={isSimulating}
        simulationGantryX={simulationGantryX}
        simulationGantryY={simulationGantryY}
        simulationStatusText={simulationStatusText}
      />

      {/* Safety & Invariant Validation Strip */}
      <div className="px-4 py-2.5 rounded-lg border bg-slate-900/60 border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          {validationWarnings.length === 0 ? (
            <>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-medium text-slate-200">
                Protocol Sequence Validated: No volume collisions or unassigned labware detected.
              </span>
            </>
          ) : (
            <>
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <div className="text-xs text-amber-300">
                <span className="font-semibold">{validationWarnings.length} Safety Check Warnings:</span>
                <span className="ml-2 font-mono text-slate-300">{validationWarnings[0]}</span>
              </div>
            </>
          )}
        </div>

        <div className="text-xs font-mono text-slate-400 flex items-center gap-3">
          <span className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-slate-500" />
            <span>Estimated Duration: {totalMinutes} min</span>
          </span>
          <span aria-hidden="true">·</span>
          <span>{steps.length} Method Steps</span>
        </div>
      </div>

      {/* Protocol Steps List & Parameter Tuning Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Step Sequence Timeline (Cols 1-6) */}
        <div className="lg:col-span-6 bg-slate-900/80 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
            <div>
              <div className="text-[11px] font-mono text-cyan-400 uppercase tracking-wider">
                Execution Workflow
              </div>
              <h3 className="text-sm font-semibold text-slate-100">
                Method Step Sequence
              </h3>
            </div>

            {/* Add Step Trigger */}
            <div className="relative">
              <button
                onClick={() => setShowAddMenu(!showAddMenu)}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-cyan-500 text-slate-950 hover:bg-cyan-400 rounded transition-colors"
              >
                <Plus className="w-3.5 h-3.5 stroke-2" />
                <span>Add Step</span>
              </button>

              {/* Step Type Dropdown */}
              {showAddMenu && (
                <div className="absolute right-0 mt-2 w-56 bg-slate-950 border border-slate-800 rounded-lg shadow-xl py-1 z-30 font-medium">
                  <div className="px-3 py-1 text-[10px] font-mono uppercase text-slate-500 border-b border-slate-800">
                    Select Automation Primitive
                  </div>
                  <button
                    onClick={() => handleAddStep('pipette_transfer')}
                    className="w-full text-left px-3 py-1.5 text-xs text-slate-200 hover:bg-slate-800 flex items-center gap-2"
                  >
                    <Pipette className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Pipette Transfer (Single/Multi)</span>
                  </button>
                  <button
                    onClick={() => handleAddStep('thermocycle')}
                    className="w-full text-left px-3 py-1.5 text-xs text-slate-200 hover:bg-slate-800 flex items-center gap-2"
                  >
                    <Flame className="w-3.5 h-3.5 text-rose-400" />
                    <span>On-Deck Thermocycle (PCR)</span>
                  </button>
                  <button
                    onClick={() => handleAddStep('magnetic_bead')}
                    className="w-full text-left px-3 py-1.5 text-xs text-slate-200 hover:bg-slate-800 flex items-center gap-2"
                  >
                    <Magnet className="w-3.5 h-3.5 text-indigo-400" />
                    <span>SPRI Magnetic Bead Separation</span>
                  </button>
                  <button
                    onClick={() => handleAddStep('incubate_shake')}
                    className="w-full text-left px-3 py-1.5 text-xs text-slate-200 hover:bg-slate-800 flex items-center gap-2"
                  >
                    <RotateCw className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Heater-Shaker Incubation</span>
                  </button>
                  <button
                    onClick={() => handleAddStep('plate_reader')}
                    className="w-full text-left px-3 py-1.5 text-xs text-slate-200 hover:bg-slate-800 flex items-center gap-2"
                  >
                    <Eye className="w-3.5 h-3.5 text-blue-400" />
                    <span>Plate Reader Spectrophotometry</span>
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Steps List */}
          <div className="space-y-2 max-h-[560px] overflow-y-auto pr-1">
            {steps.map((step, idx) => {
              const isSelected = selectedStepId === step.id;
              const isCurrentlyExecuting = isSimulating && simulationStepIndex === idx;

              return (
                <div
                  key={step.id}
                  onClick={() => setSelectedStepId(step.id)}
                  className={`p-3 rounded border transition-all cursor-pointer flex items-center justify-between ${
                    isSelected
                      ? 'bg-slate-800/90 border-cyan-500/60 ring-1 ring-cyan-500/30'
                      : 'bg-slate-950/70 border-slate-800/80 hover:border-slate-700'
                  } ${isCurrentlyExecuting ? 'border-amber-400 ring-2 ring-amber-400/50' : ''}`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    {/* Index */}
                    <div className="w-6 text-center text-xs font-mono font-semibold text-slate-500">
                      {isCurrentlyExecuting ? (
                        <div className="w-2 h-2 rounded-full bg-amber-400 animate-ping mx-auto" />
                      ) : (
                        (idx + 1).toString().padStart(2, '0')
                      )}
                    </div>

                    {/* Step Icon */}
                    <div className="p-1.5 rounded bg-slate-900 border border-slate-800 shrink-0">
                      {getStepIcon(step.type)}
                    </div>

                    {/* Meta info */}
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-slate-200 truncate flex items-center gap-2">
                        <span>{step.name}</span>
                        {isCurrentlyExecuting && (
                          <span className="text-[10px] font-mono text-amber-300 bg-amber-950/80 px-1 rounded">
                            ACTIVE
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400 truncate mt-0.5">
                        {step.description}
                      </div>
                    </div>
                  </div>

                  {/* Actions & Timing */}
                  <div className="flex items-center gap-1 shrink-0 ml-3">
                    <span className="text-[11px] font-mono text-slate-400 tabular-nums mr-2">
                      {step.durationSeconds}s
                    </span>

                    {/* Move Up */}
                    <button
                      disabled={idx === 0}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleMoveStep(idx, 'up');
                      }}
                      className="p-1 text-slate-400 hover:text-slate-200 disabled:opacity-30 rounded hover:bg-slate-800"
                      title="Move Up"
                    >
                      <ChevronUp className="w-3.5 h-3.5" />
                    </button>

                    {/* Move Down */}
                    <button
                      disabled={idx === steps.length - 1}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleMoveStep(idx, 'down');
                      }}
                      className="p-1 text-slate-400 hover:text-slate-200 disabled:opacity-30 rounded hover:bg-slate-800"
                      title="Move Down"
                    >
                      <ChevronDown className="w-3.5 h-3.5" />
                    </button>

                    {/* Duplicate */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDuplicateStep(idx);
                      }}
                      className="p-1 text-slate-400 hover:text-cyan-300 rounded hover:bg-slate-800"
                      title="Duplicate Step"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>

                    {/* Delete */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteStep(step.id);
                      }}
                      className="p-1 text-slate-400 hover:text-rose-400 rounded hover:bg-slate-800"
                      title="Delete Step"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Step Configuration Panel (Cols 7-12) */}
        <div className="lg:col-span-6">
          <StepConfigPanel
            step={selectedStep}
            onUpdateStep={handleUpdateStep}
            onDeleteStep={handleDeleteStep}
          />
        </div>
      </div>
    </div>
  );
};
