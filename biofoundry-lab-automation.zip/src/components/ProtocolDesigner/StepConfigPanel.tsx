import React from 'react';
import { ProtocolStep, StepType, LiquidClass } from '../../types/biotech';
import { 
  Sliders, 
  Pipette, 
  Flame, 
  Magnet, 
  RotateCw, 
  Disc, 
  Eye, 
  Scan,
  AlertTriangle
} from 'lucide-react';

interface StepConfigPanelProps {
  step: ProtocolStep | null;
  onUpdateStep: (updated: ProtocolStep) => void;
  onDeleteStep: (stepId: string) => void;
}

export const StepConfigPanel: React.FC<StepConfigPanelProps> = ({
  step,
  onUpdateStep,
  onDeleteStep
}) => {
  if (!step) {
    return (
      <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-6 flex flex-col items-center justify-center text-center text-slate-500 h-full min-h-[350px]">
        <Sliders className="w-10 h-10 mb-2 stroke-1 text-slate-600" />
        <h4 className="text-sm font-medium text-slate-400">No Step Selected</h4>
        <p className="text-xs text-slate-500 max-w-xs mt-1">
          Click on any protocol step in the sequence list to inspect and tune liquid handling and thermal parameters.
        </p>
      </div>
    );
  }

  const handleParamChange = (paramKey: string, value: any) => {
    onUpdateStep({
      ...step,
      parameters: {
        ...step.parameters,
        [paramKey]: value
      }
    });
  };

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4 flex flex-col gap-4">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
        <div>
          <div className="text-[11px] font-mono text-cyan-400 uppercase tracking-wider">
            Step Parameter Tuning
          </div>
          <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
            <span>{step.name}</span>
            <span className="text-xs font-mono text-slate-400 font-normal">
              ({step.type.replace('_', ' ')})
            </span>
          </h3>
        </div>
        <button
          onClick={() => onDeleteStep(step.id)}
          className="text-xs text-rose-400 hover:text-rose-300 font-medium px-2 py-1 bg-rose-950/40 border border-rose-900/60 rounded hover:bg-rose-900/60 transition-colors"
        >
          Remove Step
        </button>
      </div>

      {/* Step Basic Meta */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-medium text-slate-300 mb-1">
            Step Title
          </label>
          <input
            type="text"
            value={step.name}
            onChange={(e) => onUpdateStep({ ...step, name: e.target.value })}
            className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
          />
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-300 mb-1">
            Duration (Seconds)
          </label>
          <input
            type="number"
            value={step.durationSeconds}
            onChange={(e) => onUpdateStep({ ...step, durationSeconds: Math.max(1, Number(e.target.value)) })}
            className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-xs font-mono text-slate-200 focus:outline-none focus:border-cyan-500"
          />
        </div>
      </div>

      <div>
        <label className="block text-xs font-medium text-slate-300 mb-1">
          Detailed Description / SOP Directive
        </label>
        <textarea
          rows={2}
          value={step.description}
          onChange={(e) => onUpdateStep({ ...step, description: e.target.value })}
          className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
        />
      </div>

      {/* Dynamic Type-Specific Parameter Sections */}
      {(step.type === 'pipette_transfer' || step.type === 'multichannel_transfer') && (
        <div className="space-y-3 border-t border-slate-800/80 pt-3">
          <div className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
            <Pipette className="w-3.5 h-3.5 text-cyan-400" />
            <span>Liquid Handling & Rheology Parameters</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Transfer Vol (µL)</label>
              <input
                type="number"
                step="0.5"
                value={step.parameters.volumeMicroLitres || 20}
                onChange={(e) => handleParamChange('volumeMicroLitres', Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-xs font-mono text-cyan-300 focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Source Deck Slot</label>
              <input
                type="number"
                min="1"
                max="12"
                value={step.parameters.sourceSlot || 4}
                onChange={(e) => handleParamChange('sourceSlot', Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-xs font-mono text-slate-200 focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Destination Slot</label>
              <input
                type="number"
                min="1"
                max="12"
                value={step.parameters.destinationSlot || 5}
                onChange={(e) => handleParamChange('destinationSlot', Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-xs font-mono text-slate-200 focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Liquid Class</label>
              <select
                value={step.parameters.liquidClass || 'water'}
                onChange={(e) => handleParamChange('liquidClass', e.target.value as LiquidClass)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-xs font-mono text-slate-200 focus:border-cyan-500"
              >
                <option value="water">Standard Aqueous</option>
                <option value="viscous_glycerol">Viscous / Glycerol 50%</option>
                <option value="volatile_ethanol">Volatile (EtOH / Isopropanol)</option>
                <option value="dna_high_salt">High-Salt Nucleic Acid</option>
                <option value="mastermix">Polymerase MasterMix</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Tip Reuse Strategy</label>
              <select
                value={step.parameters.tipHandling || 'new_tip_always'}
                onChange={(e) => handleParamChange('tipHandling', e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-xs text-slate-200 focus:border-cyan-500"
              >
                <option value="new_tip_always">Fresh Tip Every Well</option>
                <option value="change_between_columns">Change Per Column</option>
                <option value="reuse_tip">Reuse (Same Reagent Only)</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Mix Repetitions</label>
              <input
                type="number"
                min="0"
                max="20"
                value={step.parameters.mixCycles ?? 3}
                onChange={(e) => handleParamChange('mixCycles', Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-xs font-mono text-slate-200 focus:border-cyan-500"
              />
            </div>

            <div className="flex items-center gap-2 pt-4">
              <input
                type="checkbox"
                id="touchTip"
                checked={step.parameters.touchTip ?? true}
                onChange={(e) => handleParamChange('touchTip', e.target.checked)}
                className="rounded border-slate-700 bg-slate-950 text-cyan-500 focus:ring-0"
              />
              <label htmlFor="touchTip" className="text-xs text-slate-300 cursor-pointer">
                Touch Tip to Well Wall
              </label>
            </div>

            <div className="flex items-center gap-2 pt-4">
              <input
                type="checkbox"
                id="airGap"
                checked={Boolean(step.parameters.airGapMicroLitres)}
                onChange={(e) => handleParamChange('airGapMicroLitres', e.target.checked ? 2.0 : 0)}
                className="rounded border-slate-700 bg-slate-950 text-cyan-500 focus:ring-0"
              />
              <label htmlFor="airGap" className="text-xs text-slate-300 cursor-pointer">
                2 µL Trailing Air Gap
              </label>
            </div>
          </div>
        </div>
      )}

      {step.type === 'thermocycle' && (
        <div className="space-y-3 border-t border-slate-800/80 pt-3">
          <div className="text-xs font-semibold text-rose-300 flex items-center gap-1.5">
            <Flame className="w-3.5 h-3.5" />
            <span>Thermocycler Profile & Ramp Parameters</span>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Heated Lid Temperature (°C)</label>
              <input
                type="number"
                value={step.parameters.lidTemperatureCelsius || 105}
                onChange={(e) => handleParamChange('lidTemperatureCelsius', Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-xs font-mono text-slate-200 focus:border-rose-500"
              />
            </div>

            <div className="flex items-center text-xs text-slate-400 font-mono pt-4">
              <span>Condensation Prevention: Active</span>
            </div>
          </div>

          {/* Cycling Stages List */}
          <div className="p-3 bg-slate-950 border border-slate-800 rounded space-y-2">
            <div className="text-[11px] font-mono uppercase text-slate-400">
              Active Thermal Profile Stages
            </div>
            {step.parameters.stages?.map((stage, sIdx) => (
              <div key={sIdx} className="border border-slate-800 p-2 rounded bg-slate-900/60">
                <div className="flex items-center justify-between text-xs font-medium text-slate-200 mb-1">
                  <span>{stage.name}</span>
                  <span className="font-mono text-cyan-400">{stage.cycles} Cycles</span>
                </div>
                <div className="flex flex-wrap gap-2 text-[11px] font-mono text-slate-400">
                  {stage.steps.map((st, i) => (
                    <span key={i} className="px-2 py-0.5 bg-slate-800 rounded">
                      {st.temperatureCelsius}°C ({st.holdTimeSeconds}s)
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {step.type === 'magnetic_bead' && (
        <div className="space-y-3 border-t border-slate-800/80 pt-3">
          <div className="text-xs font-semibold text-indigo-300 flex items-center gap-1.5">
            <Magnet className="w-3.5 h-3.5" />
            <span>Paramagnetic Bead Separation Configuration</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Binding Time (min)</label>
              <input
                type="number"
                value={step.parameters.bindingTimeMinutes || 5}
                onChange={(e) => handleParamChange('bindingTimeMinutes', Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-xs font-mono text-slate-200"
              />
            </div>
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Magnet Ring Height (mm)</label>
              <input
                type="number"
                step="0.5"
                value={step.parameters.magnetEngageHeightMm || 12.0}
                onChange={(e) => handleParamChange('magnetEngageHeightMm', Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-xs font-mono text-slate-200"
              />
            </div>
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Wash Cycles (80% EtOH)</label>
              <input
                type="number"
                value={step.parameters.washCycles || 2}
                onChange={(e) => handleParamChange('washCycles', Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-xs font-mono text-slate-200"
              />
            </div>
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Elution Volume (µL)</label>
              <input
                type="number"
                value={step.parameters.elutionVolumeMicroLitres || 20}
                onChange={(e) => handleParamChange('elutionVolumeMicroLitres', Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-xs font-mono text-slate-200"
              />
            </div>
          </div>
        </div>
      )}

      {step.type === 'incubate_shake' && (
        <div className="space-y-3 border-t border-slate-800/80 pt-3">
          <div className="text-xs font-semibold text-emerald-300 flex items-center gap-1.5">
            <RotateCw className="w-3.5 h-3.5" />
            <span>Thermal Shaking Incubation Profile</span>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Target Temp (°C)</label>
              <input
                type="number"
                value={step.parameters.temperatureCelsius || 37}
                onChange={(e) => handleParamChange('temperatureCelsius', Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-xs font-mono text-slate-200"
              />
            </div>
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Speed (RPM)</label>
              <input
                type="number"
                step="50"
                value={step.parameters.shakeRpm || 800}
                onChange={(e) => handleParamChange('shakeRpm', Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-xs font-mono text-slate-200"
              />
            </div>
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Duration (Minutes)</label>
              <input
                type="number"
                value={step.parameters.shakeDurationMinutes || 10}
                onChange={(e) => handleParamChange('shakeDurationMinutes', Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-xs font-mono text-slate-200"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
