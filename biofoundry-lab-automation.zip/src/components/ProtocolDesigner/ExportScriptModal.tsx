import React, { useState } from 'react';
import { ProtocolStep, DeckSlot } from '../../types/biotech';
import { 
  generateOpentronsPython, 
  generateHamiltonVenus, 
  generateSiLA2XML 
} from '../../utils/protocolExporter';
import { 
  X, 
  Copy, 
  Check, 
  Download, 
  Code, 
  Terminal, 
  FileCode 
} from 'lucide-react';

interface ExportScriptModalProps {
  isOpen: boolean;
  onClose: () => void;
  steps: ProtocolStep[];
  deckSlots: DeckSlot[];
}

export const ExportScriptModal: React.FC<ExportScriptModalProps> = ({
  isOpen,
  onClose,
  steps,
  deckSlots
}) => {
  const [activeFormat, setActiveFormat] = useState<'opentrons' | 'hamilton' | 'sila' | 'json'>('opentrons');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  let codeContent = '';
  let filename = '';
  let mimeType = 'text/plain';

  if (activeFormat === 'opentrons') {
    codeContent = generateOpentronsPython(steps, deckSlots);
    filename = 'biofoundry_protocol.py';
    mimeType = 'text/x-python';
  } else if (activeFormat === 'hamilton') {
    codeContent = generateHamiltonVenus(steps);
    filename = 'hamilton_venus_method.json';
    mimeType = 'application/json';
  } else if (activeFormat === 'sila') {
    codeContent = generateSiLA2XML(steps);
    filename = 'sila2_execution_schema.xml';
    mimeType = 'application/xml';
  } else {
    codeContent = JSON.stringify({ steps, deckSlots }, null, 2);
    filename = 'protocol_manifest.json';
    mimeType = 'application/json';
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(codeContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([codeContent], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-4xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div>
            <h3 className="text-base font-semibold text-slate-100 flex items-center gap-2">
              <Code className="w-4 h-4 text-cyan-400" />
              <span>Export Automation Script</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Generate native robotics driver files for execution on physical liquid handlers.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-200 rounded hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Format Selector Tabs */}
        <div className="flex items-center gap-2 px-6 pt-3 border-b border-slate-800 bg-slate-950/50">
          <button
            onClick={() => setActiveFormat('opentrons')}
            className={`pb-2 text-xs font-medium border-b-2 transition-colors flex items-center gap-1.5 ${
              activeFormat === 'opentrons'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Opentrons Python (OT-2 / Flex)</span>
          </button>

          <button
            onClick={() => setActiveFormat('hamilton')}
            className={`pb-2 text-xs font-medium border-b-2 transition-colors flex items-center gap-1.5 ${
              activeFormat === 'hamilton'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>Hamilton Venus HSL / JSON</span>
          </button>

          <button
            onClick={() => setActiveFormat('sila')}
            className={`pb-2 text-xs font-medium border-b-2 transition-colors flex items-center gap-1.5 ${
              activeFormat === 'sila'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>SiLA 2 Command XML</span>
          </button>

          <button
            onClick={() => setActiveFormat('json')}
            className={`pb-2 text-xs font-medium border-b-2 transition-colors flex items-center gap-1.5 ${
              activeFormat === 'json'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Code className="w-3.5 h-3.5" />
            <span>Raw JSON Manifest</span>
          </button>
        </div>

        {/* Code Viewport */}
        <div className="flex-1 p-4 bg-slate-950 overflow-auto font-mono text-xs text-slate-300 select-all leading-relaxed">
          <pre>{codeContent}</pre>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-3 border-t border-slate-800 bg-slate-900/90">
          <div className="text-xs font-mono text-slate-400">
            Target: <span className="text-slate-200">{filename}</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied to Clipboard' : 'Copy Code'}</span>
            </button>

            <button
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium bg-cyan-500 hover:bg-cyan-400 text-slate-950 rounded transition-colors font-semibold"
            >
              <Download className="w-3.5 h-3.5 stroke-2" />
              <span>Download File</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
