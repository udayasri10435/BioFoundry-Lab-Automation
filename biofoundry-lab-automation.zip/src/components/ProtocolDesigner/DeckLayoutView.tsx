import React, { useState } from 'react';
import { DeckSlot, LabwareType } from '../../types/biotech';
import { 
  Check, 
  Flame, 
  Magnet, 
  RotateCw, 
  Trash2, 
  Box, 
  Sliders,
  AlertCircle
} from 'lucide-react';

interface DeckLayoutViewProps {
  deckSlots: DeckSlot[];
  onUpdateSlot: (slotNumber: number, labwareType: LabwareType | null, name: string) => void;
  activeStepSourceSlot?: number;
  activeStepDestSlot?: number;
  isSimulating: boolean;
  simulationGantryX: number; // 0 to 100%
  simulationGantryY: number; // 0 to 100%
  simulationStatusText: string;
}

export const DeckLayoutView: React.FC<DeckLayoutViewProps> = ({
  deckSlots,
  onUpdateSlot,
  activeStepSourceSlot,
  activeStepDestSlot,
  isSimulating,
  simulationGantryX,
  simulationGantryY,
  simulationStatusText
}) => {
  const [selectedSlotNumber, setSelectedSlotNumber] = useState<number | null>(4);

  const selectedSlot = deckSlots.find(s => s.slotNumber === selectedSlotNumber);

  const labwareOptions: { value: LabwareType; label: string }[] = [
    { value: 'tiprack_200ul', label: '200 µL Tip Rack (96 Filter Tips)' },
    { value: 'tiprack_20ul', label: '20 µL Micro Tip Rack (96 Tips)' },
    { value: 'tiprack_1000ul', label: '1000 µL Tip Rack (96 Deep Tips)' },
    { value: 'plate_96_pcr', label: '96-Well PCR Plate (200 µL)' },
    { value: 'plate_96_deepwell', label: '96-Well Deep-Well Block (2.0 mL)' },
    { value: 'plate_384_optical', label: '384-Well Optical Clear Plate' },
    { value: 'reservoir_12_channel', label: '12-Channel Reagent Reservoir' },
    { value: 'magnetic_module', label: 'Magnetic Ring Module (96-Post)' },
    { value: 'thermocycler_module', label: 'On-Deck Thermocycler (ODTC)' },
    { value: 'heater_shaker_module', label: 'BioShake 3000 Heater-Shaker' },
    { value: 'trash_chute', label: 'Solid Waste & Tip Ejection Chute' }
  ];

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4 flex flex-col gap-4">
      {/* Deck Header & Telemetry */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-slate-100">
              ANSI/SLAS 12-Position Robotic Deck
            </span>
            <span className="text-xs font-mono text-cyan-400 bg-cyan-950/60 border border-cyan-800/60 px-2 py-0.5 rounded">
              Standard Deck V4
            </span>
          </div>
          <div className="text-xs text-slate-400 font-mono mt-0.5 flex items-center gap-2">
            <span>Dimensions: 640mm × 440mm</span>
            <span aria-hidden="true">·</span>
            <span>Gantry Resolution: 0.05mm</span>
            <span aria-hidden="true">·</span>
            <span className="text-emerald-400">pLLD Pressure Sensing Active</span>
          </div>
        </div>

        {/* Live Simulation Monitor Banner */}
        {isSimulating && (
          <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-950 border border-cyan-500/40 rounded text-xs font-mono text-cyan-300">
            <div className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
            <span>{simulationStatusText}</span>
          </div>
        )}
      </div>

      {/* Main Deck Grid and Slot Inspector Side-by-Side */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-4">
        {/* The 12-Slot Deck Arena (Cols 1-8) */}
        <div className="xl:col-span-8 relative bg-slate-950/90 rounded border border-slate-800/90 p-4 overflow-hidden">
          {/* Deck Coordinates Grid (4 columns x 3 rows = 12 standard positions) */}
          <div className="grid grid-cols-4 gap-3 relative z-10">
            {deckSlots.map((slot) => {
              const isSource = activeStepSourceSlot === slot.slotNumber;
              const isDest = activeStepDestSlot === slot.slotNumber;
              const isSelected = selectedSlotNumber === slot.slotNumber;

              let badgeColor = 'text-slate-400 border-slate-800 bg-slate-900/60';
              if (isSource) badgeColor = 'text-amber-300 border-amber-500/80 bg-amber-950/40 ring-1 ring-amber-500';
              if (isDest) badgeColor = 'text-cyan-300 border-cyan-500/80 bg-cyan-950/40 ring-1 ring-cyan-500';
              if (isSelected && !isSource && !isDest) badgeColor = 'border-slate-600 bg-slate-800/80';

              return (
                <div
                  key={slot.slotNumber}
                  onClick={() => setSelectedSlotNumber(slot.slotNumber)}
                  className={`group relative rounded p-2.5 min-h-[110px] cursor-pointer transition-all border flex flex-col justify-between ${badgeColor}`}
                >
                  {/* Slot Number Label */}
                  <div className="flex items-center justify-between text-[11px] font-mono">
                    <span className="font-semibold text-slate-300">
                      SLOT {slot.slotNumber}
                    </span>
                    {isSource && (
                      <span className="text-[10px] uppercase font-bold text-amber-400 bg-amber-900/60 px-1 rounded">
                        SOURCE
                      </span>
                    )}
                    {isDest && (
                      <span className="text-[10px] uppercase font-bold text-cyan-400 bg-cyan-900/60 px-1 rounded">
                        DEST
                      </span>
                    )}
                  </div>

                  {/* Labware Graphic & Representation */}
                  <div className="my-1.5 flex flex-col items-center justify-center text-center">
                    {slot.labwareType === 'tiprack_200ul' || slot.labwareType === 'tiprack_20ul' || slot.labwareType === 'tiprack_1000ul' ? (
                      <div className="w-full">
                        <div className="text-xs font-medium text-slate-200 truncate">
                          {slot.labwareType === 'tiprack_20ul' ? '20µL Tips' : slot.labwareType === 'tiprack_1000ul' ? '1000µL Tips' : '200µL Tips'}
                        </div>
                        {/* Mini Tip Matrix Representation */}
                        <div className="mt-1 flex items-center justify-between text-[10px] font-mono text-slate-400">
                          <span>Tips:</span>
                          <span className="text-cyan-400 font-semibold tabular-nums">
                            {slot.currentTipsRemaining || 0} / {slot.maxTips || 96}
                          </span>
                        </div>
                        <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mt-0.5">
                          <div
                            className="bg-cyan-500 h-full rounded-full transition-all"
                            style={{
                              width: `${((slot.currentTipsRemaining || 0) / (slot.maxTips || 96)) * 100}%`
                            }}
                          />
                        </div>
                      </div>
                    ) : slot.labwareType === 'thermocycler_module' ? (
                      <div className="flex flex-col items-center">
                        <Flame className="w-5 h-5 text-rose-400 mb-0.5 animate-pulse" />
                        <span className="text-xs font-medium text-slate-200 truncate">ODTC Module</span>
                        <span className="text-[10px] font-mono text-rose-300">
                          {slot.moduleState?.temperatureCelsius || 30}°C Active
                        </span>
                      </div>
                    ) : slot.labwareType === 'magnetic_module' ? (
                      <div className="flex flex-col items-center">
                        <Magnet className="w-5 h-5 text-indigo-400 mb-0.5" />
                        <span className="text-xs font-medium text-slate-200 truncate">Mag Separator</span>
                        <span className="text-[10px] font-mono text-indigo-300">Engaged 12mm</span>
                      </div>
                    ) : slot.labwareType === 'heater_shaker_module' ? (
                      <div className="flex flex-col items-center">
                        <RotateCw className="w-5 h-5 text-emerald-400 mb-0.5" />
                        <span className="text-xs font-medium text-slate-200 truncate">BioShake 3000</span>
                        <span className="text-[10px] font-mono text-emerald-300">37°C · 0 RPM</span>
                      </div>
                    ) : slot.labwareType === 'trash_chute' ? (
                      <div className="flex flex-col items-center">
                        <Trash2 className="w-5 h-5 text-slate-500 mb-0.5" />
                        <span className="text-xs font-medium text-slate-300">Waste Chute</span>
                        <span className="text-[10px] font-mono text-slate-500">Auto Eject</span>
                      </div>
                    ) : slot.labwareType ? (
                      <div className="w-full">
                        <span className="text-xs font-medium text-slate-200 block truncate">
                          {slot.name.replace(/Slot \d+:\s*/, '')}
                        </span>
                        <div className="text-[10px] font-mono text-slate-400 mt-1">
                          ANSI Standard
                        </div>
                      </div>
                    ) : (
                      <div className="py-2 text-xs font-mono text-slate-600">
                        EMPTY SLOT
                      </div>
                    )}
                  </div>

                  {/* Slot Footer Marker */}
                  <div className="text-[10px] font-mono text-slate-400 border-t border-slate-800/80 pt-1 flex justify-between">
                    <span>Pos {slot.slotNumber}</span>
                    <span className="text-slate-500 group-hover:text-cyan-400 transition-colors">
                      {isSelected ? 'Active' : 'Configure'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Robotic Pipettor Gantry Simulation Overlay */}
          {isSimulating && (
            <div
              className="absolute pointer-events-none transition-all duration-700 ease-out z-20 flex flex-col items-center -translate-x-1/2 -translate-y-1/2"
              style={{
                left: `${simulationGantryX}%`,
                top: `${simulationGantryY}%`
              }}
            >
              {/* Robotic Head Representation */}
              <div className="relative">
                <div className="w-10 h-10 rounded-full border-2 border-cyan-400 bg-cyan-950/80 flex items-center justify-center shadow-lg shadow-cyan-500/40">
                  <div className="w-2.5 h-2.5 rounded-full bg-cyan-300 animate-ping" />
                </div>
                {/* 8-Channel Pipetting Array Pins */}
                <div className="flex gap-0.5 justify-center mt-0.5">
                  {Array.from({ length: 8 }).map((_, i) => (
                    <div key={i} className="w-0.5 h-2 bg-cyan-400" />
                  ))}
                </div>
              </div>
              <div className="mt-1 bg-slate-950/95 border border-cyan-500/80 text-[10px] font-mono text-cyan-200 px-2 py-0.5 rounded shadow">
                GANTRY HEAD: 8-CH
              </div>
            </div>
          )}
        </div>

        {/* Slot Configuration Panel (Cols 9-12) */}
        <div className="xl:col-span-4 bg-slate-950/80 border border-slate-800 rounded p-4 flex flex-col justify-between">
          {selectedSlot ? (
            <div className="flex flex-col gap-4">
              <div>
                <div className="text-xs uppercase tracking-wider font-mono text-cyan-400 mb-1">
                  Slot Inspector
                </div>
                <h3 className="text-base font-semibold text-slate-100">
                  Deck Slot {selectedSlot.slotNumber} Configuration
                </h3>
                <div className="text-xs text-slate-400 mt-0.5">
                  Specify ANSI/SLAS labware or active module for this deck position.
                </div>
              </div>

              {/* Labware Assignment Dropdown */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Mounted Labware / Module
                </label>
                <select
                  value={selectedSlot.labwareType || ''}
                  onChange={(e) => {
                    const newType = (e.target.value as LabwareType) || null;
                    const opt = labwareOptions.find(o => o.value === newType);
                    onUpdateSlot(
                      selectedSlot.slotNumber, 
                      newType, 
                      opt ? `Slot ${selectedSlot.slotNumber}: ${opt.label}` : `Slot ${selectedSlot.slotNumber}: Empty`
                    );
                  }}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-cyan-500"
                >
                  <option value="">[ Empty Deck Position ]</option>
                  {labwareOptions.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* Labware Custom Name */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Display Alias / Identifier
                </label>
                <input
                  type="text"
                  value={selectedSlot.name}
                  onChange={(e) => onUpdateSlot(selectedSlot.slotNumber, selectedSlot.labwareType, e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                />
              </div>

              {/* Specific Module or Labware Settings */}
              {selectedSlot.labwareType?.startsWith('tiprack') && (
                <div className="p-3 bg-slate-900/90 border border-slate-800 rounded">
                  <div className="text-xs font-semibold text-slate-200 mb-2">
                    Tip Inventory State
                  </div>
                  <div className="flex items-center justify-between text-xs text-slate-300 font-mono mb-2">
                    <span>Remaining Tips:</span>
                    <span className="text-cyan-400 font-bold">
                      {selectedSlot.currentTipsRemaining || 0} / 96
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      onUpdateSlot(selectedSlot.slotNumber, selectedSlot.labwareType, selectedSlot.name);
                      // Reset to 96
                      selectedSlot.currentTipsRemaining = 96;
                    }}
                    className="w-full py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded font-medium border border-slate-700 transition-colors"
                  >
                    Replenish Fresh Tip Box (Reset to 96)
                  </button>
                </div>
              )}

              {selectedSlot.labwareType === 'thermocycler_module' && (
                <div className="p-3 bg-slate-900/90 border border-slate-800 rounded space-y-2">
                  <div className="text-xs font-semibold text-rose-300 flex items-center gap-1.5">
                    <Flame className="w-3.5 h-3.5" />
                    <span>ODTC Module Telemetry</span>
                  </div>
                  <div className="text-xs font-mono text-slate-300 flex justify-between">
                    <span>Block Temp:</span>
                    <span className="text-slate-100">30.0 °C</span>
                  </div>
                  <div className="text-xs font-mono text-slate-300 flex justify-between">
                    <span>Heated Lid:</span>
                    <span className="text-slate-100">105.0 °C (Ready)</span>
                  </div>
                </div>
              )}

              {selectedSlot.labwareType === 'magnetic_module' && (
                <div className="p-3 bg-slate-900/90 border border-slate-800 rounded space-y-2">
                  <div className="text-xs font-semibold text-indigo-300 flex items-center gap-1.5">
                    <Magnet className="w-3.5 h-3.5" />
                    <span>Magnetic Separator Ring</span>
                  </div>
                  <div className="text-xs font-mono text-slate-300 flex justify-between">
                    <span>Post Engagement:</span>
                    <span className="text-indigo-400">12.0 mm (Raised)</span>
                  </div>
                  <div className="text-xs font-mono text-slate-300 flex justify-between">
                    <span>Neodymium Rating:</span>
                    <span className="text-slate-100">N52 High-Flux</span>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-48 text-center text-slate-500">
              <Box className="w-8 h-8 mb-2 stroke-1" />
              <div className="text-xs">Select any deck slot to configure its labware.</div>
            </div>
          )}

          {/* Quick Deck Validation Summary */}
          <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] font-mono text-slate-400 flex items-center justify-between">
            <span className="text-emerald-400 flex items-center gap-1">
              <Check className="w-3.5 h-3.5" />
              <span>Deck Clearance Validated</span>
            </span>
            <span>ANSI/SLAS Certified</span>
          </div>
        </div>
      </div>
    </div>
  );
};
