import React from 'react';
import { Reagent } from '../../types/biotech';
import { 
  Database, 
  Snowflake, 
  Flame, 
  AlertTriangle, 
  Skull, 
  Plus, 
  RotateCcw,
  CheckCircle2
} from 'lucide-react';

interface ReagentInventoryProps {
  reagents: Reagent[];
  onLogFreezeThaw: (reagentId: string) => void;
  onReplenish: (reagentId: string) => void;
}

export const ReagentInventory: React.FC<ReagentInventoryProps> = ({
  reagents,
  onLogFreezeThaw,
  onReplenish
}) => {
  return (
    <div className="flex flex-col gap-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-semibold text-slate-100 flex items-center gap-2">
            <Database className="w-4 h-4 text-cyan-400" />
            <span>Reagent & Consumable Lot Inventory</span>
          </h2>
          <div className="text-xs text-slate-400 font-mono mt-0.5 flex items-center gap-2">
            <span>Cold-Chain Custody</span>
            <span aria-hidden="true">·</span>
            <span>Freeze-Thaw Degradation Tracking</span>
            <span aria-hidden="true">·</span>
            <span>GHS Safety Compliance</span>
          </div>
        </div>
      </div>

      {/* Reagents Table / Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {reagents.map((reagent) => {
          const isFreezeThawWarning = reagent.freezeThawCount >= reagent.maxFreezeThaw;
          const isNearFreezeThaw = reagent.freezeThawCount === reagent.maxFreezeThaw - 1;
          const volumePercent = (reagent.currentVolumeMl / reagent.initialVolumeMl) * 100;

          return (
            <div
              key={reagent.id}
              className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 flex flex-col justify-between hover:border-slate-700 transition-all shadow-sm"
            >
              <div>
                {/* Header Row */}
                <div className="flex items-start justify-between gap-2 border-b border-slate-800/80 pb-3">
                  <div>
                    <h3 className="text-sm font-semibold text-slate-100">
                      {reagent.name}
                    </h3>
                    <div className="text-xs font-mono text-slate-400 mt-0.5 flex items-center gap-2">
                      <span>Cat #: {reagent.catalogNumber}</span>
                      <span aria-hidden="true">·</span>
                      <span className="text-slate-300">Vendor: {reagent.vendor}</span>
                    </div>
                  </div>

                  {/* Storage Temperature Badge */}
                  <div className="flex items-center gap-1 text-xs font-mono text-cyan-300 bg-cyan-950/60 border border-cyan-800/60 px-2.5 py-1 rounded">
                    <Snowflake className="w-3.5 h-3.5" />
                    <span>{reagent.storageCondition}</span>
                  </div>
                </div>

                {/* Lot & Expiry & GHS Hazards */}
                <div className="grid grid-cols-2 gap-3 my-3 text-xs">
                  <div className="bg-slate-950/60 p-2.5 rounded border border-slate-800/80">
                    <div className="text-[10px] font-mono text-slate-500 uppercase">
                      Lot Number
                    </div>
                    <div className="font-mono font-semibold text-slate-200 mt-0.5">
                      {reagent.lotNumber}
                    </div>
                  </div>

                  <div className="bg-slate-950/60 p-2.5 rounded border border-slate-800/80">
                    <div className="text-[10px] font-mono text-slate-500 uppercase">
                      Expiration Date
                    </div>
                    <div className="font-mono font-semibold text-slate-200 mt-0.5">
                      {reagent.expirationDate}
                    </div>
                  </div>
                </div>

                {/* Volume Level Bar */}
                <div className="my-3">
                  <div className="flex items-center justify-between text-xs font-mono mb-1">
                    <span className="text-slate-400">Current Volume Remaining:</span>
                    <span className="text-slate-200 font-bold tabular-nums">
                      {reagent.currentVolumeMl} / {reagent.initialVolumeMl} mL ({volumePercent.toFixed(0)}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        volumePercent < 20 ? 'bg-rose-500' : volumePercent < 50 ? 'bg-amber-500' : 'bg-cyan-500'
                      }`}
                      style={{ width: `${volumePercent}%` }}
                    />
                  </div>
                </div>

                {/* Freeze-Thaw Degradation Tracker */}
                <div className="p-3 bg-slate-950 rounded border border-slate-800 my-2">
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="text-slate-300 font-medium">Freeze-Thaw Cycles:</span>
                    <span
                      className={`font-mono font-bold ${
                        isFreezeThawWarning
                          ? 'text-rose-400'
                          : isNearFreezeThaw
                          ? 'text-amber-400'
                          : 'text-emerald-400'
                      }`}
                    >
                      {reagent.freezeThawCount} of {reagent.maxFreezeThaw} max allowed
                    </span>
                  </div>

                  {isFreezeThawWarning && (
                    <div className="flex items-center gap-1.5 text-[11px] font-mono text-rose-400 bg-rose-950/60 border border-rose-900/60 p-1.5 rounded mt-2">
                      <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                      <span>Degradation Warning: Exceeded validated freeze-thaw cycles! Discard lot.</span>
                    </div>
                  )}

                  {/* GHS Hazard Flags */}
                  <div className="flex items-center gap-2 mt-2 pt-2 border-t border-slate-800/80">
                    <span className="text-[10px] font-mono uppercase text-slate-500">GHS Classification:</span>
                    {reagent.hazardClass.map((hz, idx) => (
                      <span
                        key={idx}
                        className="text-[10px] font-mono text-slate-300 bg-slate-800 px-1.5 py-0.5 rounded capitalize"
                      >
                        {hz === 'flammable' && '🔥 Flammable (Cat 2)'}
                        {hz === 'toxic' && '⚠️ Toxic / Biohazard'}
                        {hz === 'corrosive' && '🧪 Corrosive'}
                        {hz === 'none' && 'Non-Hazardous'}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="border-t border-slate-800 pt-3 flex items-center justify-between gap-2 mt-2">
                <button
                  onClick={() => onLogFreezeThaw(reagent.id)}
                  disabled={isFreezeThawWarning}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 text-xs font-medium rounded transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Log Thaw Cycle (+1)</span>
                </button>

                <button
                  onClick={() => onReplenish(reagent.id)}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-medium rounded transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Replenish Lot</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
