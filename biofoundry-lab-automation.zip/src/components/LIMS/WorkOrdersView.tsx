import React, { useState } from 'react';
import { WorkOrder } from '../../types/biotech';
import { 
  FileText, 
  Plus, 
  Search, 
  Clock, 
  User, 
  Layers, 
  AlertCircle,
  CheckCircle2,
  Calendar,
  X
} from 'lucide-react';

interface WorkOrdersViewProps {
  workOrders: WorkOrder[];
  onAddWorkOrder: (order: WorkOrder) => void;
  onUpdateStatus: (orderId: string, status: WorkOrder['status']) => void;
  onSelectPlateBarcode?: (barcode: string) => void;
}

export const WorkOrdersView: React.FC<WorkOrdersViewProps> = ({
  workOrders,
  onAddWorkOrder,
  onUpdateStatus,
  onSelectPlateBarcode
}) => {
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isNewModalOpen, setIsNewModalOpen] = useState(false);

  // New Work Order form state
  const [newTitle, setNewTitle] = useState('');
  const [newAssay, setNewAssay] = useState('Illumina TruSeq DNA WES');
  const [newSampleCount, setNewSampleCount] = useState(96);
  const [newSubmitter, setNewSubmitter] = useState('');
  const [newOperator, setNewOperator] = useState('Current Operator');
  const [newPriority, setNewPriority] = useState<WorkOrder['priority']>('routine');
  const [newNotes, setNewNotes] = useState('');

  const filteredOrders = workOrders.filter(wo => {
    const matchesStatus = filterStatus === 'all' || wo.status === filterStatus;
    const matchesSearch = wo.orderNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          wo.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          wo.assayType.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const handleCreateOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const orderNum = `WO-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const newWo: WorkOrder = {
      id: `wo-${Date.now()}`,
      orderNumber: orderNum,
      title: newTitle,
      assayType: newAssay,
      sampleCount: newSampleCount,
      submitter: newSubmitter || 'Biofoundry Client',
      operator: newOperator || 'Lab Automation Lead',
      status: 'queued',
      priority: newPriority,
      createdAt: new Date().toISOString(),
      dueDate: new Date(Date.now() + 86400000 * 2).toISOString(),
      protocolId: 'step-1',
      inputPlateBarcodes: [`PLT-96-INP-${Math.floor(100 + Math.random() * 900)}`],
      outputPlateBarcodes: [`PLT-96-OUT-${Math.floor(100 + Math.random() * 900)}`],
      notes: newNotes
    };

    onAddWorkOrder(newWo);
    setIsNewModalOpen(false);
    setNewTitle('');
    setNewNotes('');
  };

  const getStatusColor = (status: WorkOrder['status']) => {
    switch (status) {
      case 'in_progress':
        return 'text-cyan-400 bg-cyan-950/60 border-cyan-800/80';
      case 'queued':
        return 'text-slate-300 bg-slate-800/80 border-slate-700';
      case 'qc_review':
        return 'text-amber-400 bg-amber-950/60 border-amber-800/80';
      case 'completed':
        return 'text-emerald-400 bg-emerald-950/60 border-emerald-800/80';
      case 'on_hold':
        return 'text-rose-400 bg-rose-950/60 border-rose-800/80';
    }
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Top Header Actions */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-semibold text-slate-100 flex items-center gap-2">
            <FileText className="w-4 h-4 text-cyan-400" />
            <span>Laboratory Information Management System (LIMS)</span>
          </h2>
          <div className="text-xs text-slate-400 font-mono mt-0.5 flex items-center gap-2">
            <span>Work Orders & Assay Batch Queue</span>
            <span aria-hidden="true">·</span>
            <span>GLP & 21 CFR Part 11 Traceability</span>
          </div>
        </div>

        <button
          onClick={() => setIsNewModalOpen(true)}
          className="flex items-center gap-1.5 px-3.5 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-semibold rounded transition-colors"
        >
          <Plus className="w-3.5 h-3.5 stroke-2" />
          <span>New Work Order Batch</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/80 border border-slate-800 p-3 rounded-lg">
        {/* Status Filters */}
        <div className="flex items-center gap-1 overflow-x-auto">
          {['all', 'queued', 'in_progress', 'qc_review', 'completed'].map((st) => (
            <button
              key={st}
              onClick={() => setFilterStatus(st)}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                filterStatus === st
                  ? 'bg-slate-800 text-cyan-300 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {st === 'all' ? 'All Orders' : st.replace('_', ' ').toUpperCase()}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500" />
          <input
            type="text"
            placeholder="Search Order ID, Assay, Submitter..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-700/80 rounded pl-8 pr-3 py-1 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
          />
        </div>
      </div>

      {/* Orders List */}
      <div className="grid grid-cols-1 gap-4">
        {filteredOrders.map((order) => {
          return (
            <div
              key={order.id}
              className="bg-slate-900/80 border border-slate-800 rounded-lg p-4 hover:border-slate-700 transition-colors flex flex-col justify-between"
            >
              <div>
                <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-800/80 pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-cyan-400">
                        {order.orderNumber}
                      </span>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <h3 className="text-sm font-semibold text-slate-100">
                        {order.title}
                      </h3>
                      {order.priority === 'urgent' && (
                        <span className="text-[10px] font-mono font-bold text-amber-400 bg-amber-950/80 border border-amber-800/80 px-1.5 py-0.5 rounded">
                          URGENT
                        </span>
                      )}
                      {order.priority === 'stat' && (
                        <span className="text-[10px] font-mono font-bold text-rose-400 bg-rose-950/80 border border-rose-800/80 px-1.5 py-0.5 rounded">
                          STAT EMERGENCY
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-slate-400 mt-1 flex flex-wrap items-center gap-3">
                      <span>Assay: <strong className="text-slate-300">{order.assayType}</strong></span>
                      <span aria-hidden="true">·</span>
                      <span>Sample Cohort: <strong className="text-slate-300 font-mono">{order.sampleCount} wells</strong></span>
                      <span aria-hidden="true">·</span>
                      <span>Submitter: <span className="text-slate-300">{order.submitter}</span></span>
                    </div>
                  </div>

                  {/* Status Dropdown */}
                  <div className="flex items-center gap-2">
                    <select
                      value={order.status}
                      onChange={(e) => onUpdateStatus(order.id, e.target.value as WorkOrder['status'])}
                      className={`text-xs font-mono font-semibold rounded px-2.5 py-1 border focus:outline-none cursor-pointer ${getStatusColor(order.status)}`}
                    >
                      <option value="queued" className="bg-slate-900 text-slate-200">QUEUED</option>
                      <option value="in_progress" className="bg-slate-900 text-cyan-300">IN PROGRESS</option>
                      <option value="qc_review" className="bg-slate-900 text-amber-300">QC REVIEW</option>
                      <option value="completed" className="bg-slate-900 text-emerald-300">COMPLETED</option>
                      <option value="on_hold" className="bg-slate-900 text-rose-300">ON HOLD</option>
                    </select>
                  </div>
                </div>

                {/* Body Notes & Plate Barcodes */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-3 text-xs">
                  <div>
                    <div className="text-[11px] font-mono text-slate-500 uppercase mb-1">
                      Assigned Microplate Barcodes
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {order.inputPlateBarcodes.map((bc, idx) => (
                        <button
                          key={idx}
                          onClick={() => onSelectPlateBarcode?.(bc)}
                          className="px-2 py-0.5 rounded bg-slate-950 border border-slate-700/80 font-mono text-cyan-300 hover:border-cyan-400 transition-colors"
                        >
                          Input: {bc}
                        </button>
                      ))}
                      {order.outputPlateBarcodes.map((bc, idx) => (
                        <span
                          key={idx}
                          className="px-2 py-0.5 rounded bg-slate-950 border border-slate-700/80 font-mono text-emerald-300"
                        >
                          Output: {bc}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <div className="text-[11px] font-mono text-slate-500 uppercase mb-1">
                      Handling Notes & Invariants
                    </div>
                    <p className="text-slate-300 text-xs">
                      {order.notes || 'Standard protocol execution parameters applied.'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Order Footer */}
              <div className="border-t border-slate-800/80 pt-2 flex flex-wrap items-center justify-between text-[11px] font-mono text-slate-400">
                <div className="flex items-center gap-3">
                  <span>Operator: {order.operator}</span>
                  <span aria-hidden="true">·</span>
                  <span>Submitted: {new Date(order.createdAt).toLocaleDateString()}</span>
                </div>
                <div>
                  Turnaround Due: <span className="text-slate-200">{new Date(order.dueDate).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* New Work Order Modal */}
      {isNewModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-xl shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
              <h3 className="text-base font-semibold text-slate-100 flex items-center gap-2">
                <Plus className="w-4 h-4 text-cyan-400" />
                <span>Create New LIMS Work Order</span>
              </h3>
              <button
                onClick={() => setIsNewModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-200 rounded"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateOrder} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Batch Order Title
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. CRISPR Cas9 Editing Screen (Plate B)"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Assay Protocol
                  </label>
                  <select
                    value={newAssay}
                    onChange={(e) => setNewAssay(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                  >
                    <option value="Illumina TruSeq DNA WES">Illumina TruSeq DNA WES</option>
                    <option value="Golden Gate Modular Assembly">Golden Gate Modular Assembly</option>
                    <option value="384-Well IC50 Titration">384-Well IC50 Titration</option>
                    <option value="Plasmid Miniprep Extraction">Plasmid Miniprep Extraction</option>
                    <option value="RNA-Seq PolyA Isolation">RNA-Seq PolyA Isolation</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Sample Count (Wells)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="384"
                    value={newSampleCount}
                    onChange={(e) => setNewSampleCount(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs font-mono text-slate-200 focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Principal Investigator / Submitter
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Dr. Jane Doe"
                    value={newSubmitter}
                    onChange={(e) => setNewSubmitter(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Priority SLA
                  </label>
                  <select
                    value={newPriority}
                    onChange={(e) => setNewPriority(e.target.value as WorkOrder['priority'])}
                    className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                  >
                    <option value="routine">Routine (5-Day Turnaround)</option>
                    <option value="urgent">Urgent (48-Hour SLA)</option>
                    <option value="stat">STAT Emergency (Same-Day)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Special Instructions / Quality Specifications
                </label>
                <textarea
                  rows={3}
                  placeholder="e.g. Require minimum DIN > 7.0 and PicoGreen recovery > 80%."
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsNewModalOpen(false)}
                  className="px-4 py-1.5 text-xs text-slate-400 hover:text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-semibold rounded"
                >
                  Dispatch to Automation Queue
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
