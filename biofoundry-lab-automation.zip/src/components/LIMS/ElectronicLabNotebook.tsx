import React, { useState } from 'react';
import { ELNAuditEntry } from '../../types/biotech';
import { 
  FileCheck, 
  ShieldCheck, 
  Key, 
  Lock, 
  UserCheck, 
  Clock, 
  Check, 
  AlertCircle 
} from 'lucide-react';

interface ELNProps {
  entries: ELNAuditEntry[];
  onAddSignature: (operatorName: string, action: string, details: string) => void;
}

export const ElectronicLabNotebook: React.FC<ELNProps> = ({
  entries,
  onAddSignature
}) => {
  const [operatorInput, setOperatorInput] = useState('Marcus Vance, Lead Automation Spec');
  const [pinInput, setPinInput] = useState('****');
  const [reasonInput, setReasonInput] = useState('I verify this automated assay was conducted in strict adherence to SOP-GEN-410.');
  const [isSignOpen, setIsSignOpen] = useState(false);
  const [signSuccess, setSignSuccess] = useState(false);

  const handleSign = (e: React.FormEvent) => {
    e.preventDefault();
    if (!operatorInput.trim() || !reasonInput.trim()) return;

    onAddSignature(
      operatorInput,
      '21 CFR Part 11 Electronic Signature Executed',
      reasonInput
    );

    setSignSuccess(true);
    setTimeout(() => {
      setSignSuccess(false);
      setIsSignOpen(false);
    }, 1500);
  };

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-6 flex flex-col gap-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h3 className="text-base font-semibold text-slate-100">
              Electronic Lab Notebook (ELN) Audit Trail
            </h3>
          </div>
          <div className="text-xs text-slate-400 font-mono mt-0.5 flex items-center gap-2">
            <span>FDA 21 CFR Part 11 Compliant</span>
            <span aria-hidden="true">·</span>
            <span>Immutable Hash Chaining</span>
            <span aria-hidden="true">·</span>
            <span className="text-emerald-400">Cryptographically Sealed</span>
          </div>
        </div>

        <button
          onClick={() => setIsSignOpen(!isSignOpen)}
          className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-semibold rounded transition-colors"
        >
          <Key className="w-3.5 h-3.5" />
          <span>Digitally Sign Run Sheet</span>
        </button>
      </div>

      {/* Signature Prompt Box */}
      {isSignOpen && (
        <form onSubmit={handleSign} className="bg-slate-950 border border-emerald-500/40 rounded-lg p-4 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-400 uppercase font-mono tracking-wider flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5" />
              Digital Signature Attestation
            </span>
            <span className="text-[11px] font-mono text-slate-500">21 CFR §11.200</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Authorized Signer
              </label>
              <input
                type="text"
                required
                value={operatorInput}
                onChange={(e) => setOperatorInput(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-200"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Security PIN / Credential Token
              </label>
              <input
                type="password"
                required
                value={pinInput}
                onChange={(e) => setPinInput(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-xs font-mono text-slate-200"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Affirmation / Signing Reason
            </label>
            <input
              type="text"
              required
              value={reasonInput}
              onChange={(e) => setReasonInput(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-xs text-slate-200"
            />
          </div>

          <div className="flex items-center justify-between pt-2">
            <span className="text-[11px] font-mono text-slate-500">
              By clicking Sign, you affix an immutable electronic signature to this record.
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsSignOpen(false)}
                className="px-3 py-1 text-xs text-slate-400 hover:text-slate-200"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex items-center gap-1.5 px-4 py-1.5 bg-emerald-500 text-slate-950 font-semibold text-xs rounded hover:bg-emerald-400"
              >
                {signSuccess ? <Check className="w-3.5 h-3.5" /> : <ShieldCheck className="w-3.5 h-3.5" />}
                <span>{signSuccess ? 'Signature Affixed!' : 'Affix Digital Signature'}</span>
              </button>
            </div>
          </div>
        </form>
      )}

      {/* Audit Log Chronology */}
      <div className="space-y-3">
        {entries.map((entry) => (
          <div
            key={entry.id}
            className="p-3.5 rounded-lg bg-slate-950/70 border border-slate-800/80 flex flex-col md:flex-row md:items-center justify-between gap-3"
          >
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-200 font-mono">
                  {entry.action}
                </span>
                <span className="text-[11px] text-emerald-400 font-mono bg-emerald-950/80 border border-emerald-800/80 px-1.5 py-0.2 rounded">
                  VERIFIED
                </span>
              </div>
              <p className="text-xs text-slate-300">
                {entry.details}
              </p>
              <div className="text-[11px] font-mono text-slate-500 flex flex-wrap items-center gap-3">
                <span>By: {entry.operator}</span>
                <span aria-hidden="true">·</span>
                <span>Timestamp: {new Date(entry.timestamp).toLocaleString()}</span>
              </div>
            </div>

            {/* Cryptographic SHA256 Signature Chip */}
            <div className="bg-slate-900 border border-slate-800 p-2 rounded text-[10px] font-mono text-slate-400 shrink-0 self-start md:self-center">
              <div className="text-slate-500 uppercase">SHA-256 Checksum:</div>
              <div className="text-cyan-400 truncate max-w-[200px]">{entry.signatureHash}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
