import React, { useState, useEffect } from 'react';
import { 
  IndustryProfile, 
  ProtocolStep, 
  DeckSlot, 
  Instrument, 
  Microplate, 
  WorkOrder, 
  Reagent, 
  ELNAuditEntry,
  LabwareType
} from './types/biotech';
import { 
  initialGenomicsProtocol, 
  initialSynBioProtocol, 
  initialCROProtocol, 
  initialDeckSlots, 
  initialInstruments, 
  initialReagents, 
  initialWorkOrders, 
  initialELNLogs, 
  generate96WellPlate 
} from './data/mockData';
import { Header } from './components/Header';
import { ProtocolEditor } from './components/ProtocolDesigner/ProtocolEditor';
import { ExportScriptModal } from './components/ProtocolDesigner/ExportScriptModal';
import { FleetMonitor } from './components/InstrumentIntegration/FleetMonitor';
import { LiveTelemetryModal } from './components/InstrumentIntegration/LiveTelemetryModal';
import { WorkOrdersView } from './components/LIMS/WorkOrdersView';
import { ElectronicLabNotebook } from './components/LIMS/ElectronicLabNotebook';
import { ReagentInventory } from './components/LIMS/ReagentInventory';
import { MicroplateVisualizer } from './components/SampleTracking/MicroplateVisualizer';

export default function App() {
  // Navigation & Profile
  const [currentTab, setCurrentTab] = useState<'protocol' | 'instruments' | 'lims' | 'samples' | 'reagents'>('protocol');
  const [activeProfile, setActiveProfile] = useState<IndustryProfile>('genomics');

  // Core Data States
  const [steps, setSteps] = useState<ProtocolStep[]>(initialGenomicsProtocol);
  const [deckSlots, setDeckSlots] = useState<DeckSlot[]>(initialDeckSlots);
  const [instruments, setInstruments] = useState<Instrument[]>(initialInstruments);
  const [reagents, setReagents] = useState<Reagent[]>(initialReagents);
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>(initialWorkOrders);
  const [elnEntries, setElnEntries] = useState<ELNAuditEntry[]>(initialELNLogs);
  const [plate, setPlate] = useState<Microplate>(() => 
    generate96WellPlate('plt-01', 'PLT-96-DNA-0841', 'Plate 1: Primary Cohort (96-Well PCR)', 'GENOM-2026')
  );

  // Modals & Inspection
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [inspectedInstrument, setInspectedInstrument] = useState<Instrument | null>(null);

  // Simulation State
  const [isSimulating, setIsSimulating] = useState(false);
  const [simulationStepIndex, setSimulationStepIndex] = useState(0);
  const [simulationGantryX, setSimulationGantryX] = useState(30);
  const [simulationGantryY, setSimulationGantryY] = useState(40);
  const [simulationStatusText, setSimulationStatusText] = useState('Idle');

  // Handle Domain Switch
  const handleChangeProfile = (profile: IndustryProfile) => {
    setActiveProfile(profile);
    setIsSimulating(false);

    if (profile === 'genomics') {
      setSteps(initialGenomicsProtocol);
      setPlate(generate96WellPlate('plt-genom-01', 'PLT-96-DNA-0841', 'Genomics WGS Library Prep Plate', 'GENOM-2026'));
    } else if (profile === 'synbio') {
      setSteps(initialSynBioProtocol);
      setPlate(generate96WellPlate('plt-synbio-01', 'PLT-96-SYN-0012', 'SynBio Golden Gate Biobrick Assembly Plate', 'SYNBIO-BB'));
    } else if (profile === 'cro') {
      setSteps(initialCROProtocol);
      setPlate(generate96WellPlate('plt-cro-01', 'PLT-384-CPD-092', 'CRO 12-Point IC50 Compound Titration Plate', 'CPD-ADME'));
    }

    // Append to ELN log
    const auditRecord: ELNAuditEntry = {
      id: `eln-${Date.now()}`,
      timestamp: new Date().toISOString(),
      operator: 'Marcus Vance, Automation Spec',
      action: 'Domain Profile Switched',
      details: `Switched operational context to ${profile.toUpperCase()} profile. Protocols and deck labware re-indexed.`,
      signatureHash: Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
      verified: true
    };
    setElnEntries(prev => [auditRecord, ...prev]);
  };

  // Deck Slot Update
  const handleUpdateSlot = (slotNumber: number, labwareType: LabwareType | null, name: string) => {
    setDeckSlots(prev => prev.map(s => {
      if (s.slotNumber === slotNumber) {
        return {
          ...s,
          labwareType,
          name,
          isOccupied: Boolean(labwareType)
        };
      }
      return s;
    }));
  };

  // Hardware Fleet Command Handlers
  const handleTriggerInstrumentAction = (instrumentId: string, action: 'pause' | 'resume' | 'estop' | 'home' | 'lock_toggle') => {
    setInstruments(prev => prev.map(inst => {
      if (inst.id === instrumentId) {
        if (action === 'pause') {
          return { ...inst, status: 'warning' };
        }
        if (action === 'resume') {
          return { ...inst, status: 'running' };
        }
        if (action === 'estop') {
          return { ...inst, status: 'error', progressPercent: 0 };
        }
        if (action === 'home') {
          return { ...inst, status: 'idle' };
        }
      }
      return inst;
    }));

    // Record in ELN
    const entry: ELNAuditEntry = {
      id: `eln-${Date.now()}`,
      timestamp: new Date().toISOString(),
      operator: 'Marcus Vance, Lead Automation Spec',
      action: `Hardware Action: ${action.toUpperCase()}`,
      details: `Dispatched command [${action}] to instrument ${instrumentId}. Interlock state verified.`,
      signatureHash: Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
      verified: true
    };
    setElnEntries(prev => [entry, ...prev]);
  };

  // Simulation Loop
  useEffect(() => {
    if (!isSimulating) return;

    const interval = setInterval(() => {
      setSimulationStepIndex(prev => {
        const next = (prev + 1) % steps.length;
        const currentStep = steps[next];
        
        // Compute realistic gantry coordinates on deck (slots 1-12)
        const sSlot = currentStep?.parameters?.sourceSlot || 4;
        const col = ((sSlot - 1) % 4);
        const row = Math.floor((sSlot - 1) / 4);
        setSimulationGantryX(18 + col * 24);
        setSimulationGantryY(20 + row * 28);
        setSimulationStatusText(`Executing: ${currentStep?.name || 'Aspirating'}`);

        return next;
      });

      // Update instrument progress
      setInstruments(prev => prev.map(inst => {
        if (inst.category === 'liquid_handler' && inst.status === 'running') {
          const nextProg = Math.min(100, (inst.progressPercent + 3) % 100);
          return {
            ...inst,
            progressPercent: nextProg,
            elapsedSeconds: inst.elapsedSeconds + 10,
            telemetry: {
              ...inst.telemetry,
              pressureLldMbar: Number((1013.2 + (Math.sin(Date.now() / 2000) * 12)).toFixed(1))
            }
          };
        }
        return inst;
      }));
    }, 2800);

    return () => clearInterval(interval);
  }, [isSimulating, steps]);

  const handleToggleSimulation = () => {
    if (!isSimulating) {
      setIsSimulating(true);
      setSimulationStepIndex(0);
      setSimulationStatusText('Initializing Robotic Gantry and pLLD Sensors...');
    } else {
      setIsSimulating(false);
      setSimulationStatusText('Simulation Paused');
    }
  };

  // LIMS Handlers
  const handleAddWorkOrder = (order: WorkOrder) => {
    setWorkOrders(prev => [order, ...prev]);
  };

  const handleUpdateOrderStatus = (orderId: string, status: WorkOrder['status']) => {
    setWorkOrders(prev => prev.map(wo => wo.id === orderId ? { ...wo, status } : wo));
  };

  const handleLogFreezeThaw = (reagentId: string) => {
    setReagents(prev => prev.map(r => {
      if (r.id === reagentId) {
        return {
          ...r,
          freezeThawCount: r.freezeThawCount + 1
        };
      }
      return r;
    }));
  };

  const handleReplenishReagent = (reagentId: string) => {
    setReagents(prev => prev.map(r => {
      if (r.id === reagentId) {
        return {
          ...r,
          currentVolumeMl: r.initialVolumeMl,
          freezeThawCount: 0
        };
      }
      return r;
    }));
  };

  const handleAddSignature = (operator: string, action: string, details: string) => {
    const entry: ELNAuditEntry = {
      id: `eln-${Date.now()}`,
      timestamp: new Date().toISOString(),
      operator,
      action,
      details,
      signatureHash: Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
      verified: true
    };
    setElnEntries(prev => [entry, ...prev]);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Top 3-Zone Navigation Bar */}
      <Header
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        activeProfile={activeProfile}
        onChangeProfile={handleChangeProfile}
        isSimulating={isSimulating}
        onToggleSimulation={handleToggleSimulation}
        onOpenExportModal={() => setIsExportModalOpen(true)}
      />

      {/* Main Scientific Workspace Container */}
      <main className="flex-1 w-full max-w-[1520px] mx-auto p-4 sm:p-6 lg:p-8">
        {currentTab === 'protocol' && (
          <ProtocolEditor
            steps={steps}
            onUpdateSteps={setSteps}
            deckSlots={deckSlots}
            onUpdateSlot={handleUpdateSlot}
            isSimulating={isSimulating}
            simulationStepIndex={simulationStepIndex}
            simulationGantryX={simulationGantryX}
            simulationGantryY={simulationGantryY}
            simulationStatusText={simulationStatusText}
          />
        )}

        {currentTab === 'instruments' && (
          <FleetMonitor
            instruments={instruments}
            onTriggerAction={handleTriggerInstrumentAction}
            onSelectInstrument={(inst) => setInspectedInstrument(inst)}
          />
        )}

        {currentTab === 'lims' && (
          <div className="space-y-8">
            <WorkOrdersView
              workOrders={workOrders}
              onAddWorkOrder={handleAddWorkOrder}
              onUpdateStatus={handleUpdateOrderStatus}
              onSelectPlateBarcode={(bc) => {
                setCurrentTab('samples');
              }}
            />

            <ElectronicLabNotebook
              entries={elnEntries}
              onAddSignature={handleAddSignature}
            />
          </div>
        )}

        {currentTab === 'samples' && (
          <MicroplateVisualizer
            plate={plate}
            onUpdatePlate={setPlate}
          />
        )}

        {currentTab === 'reagents' && (
          <ReagentInventory
            reagents={reagents}
            onLogFreezeThaw={handleLogFreezeThaw}
            onReplenish={handleReplenishReagent}
          />
        )}
      </main>

      {/* Script Exporter Modal */}
      <ExportScriptModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        steps={steps}
        deckSlots={deckSlots}
      />

      {/* Instrument Detailed Telemetry & SiLA Stream Modal */}
      <LiveTelemetryModal
        instrument={inspectedInstrument}
        onClose={() => setInspectedInstrument(null)}
      />

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-4 px-6 text-xs font-mono text-slate-500 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span>BioFoundry OS</span>
          <span aria-hidden="true">·</span>
          <span>SiLA 2 Interoperability Standard</span>
          <span aria-hidden="true">·</span>
          <span>ANSI/SLAS Microplate Specification</span>
        </div>
        <div className="text-slate-600">
          Precision High-Throughput Automation Architecture
        </div>
      </footer>
    </div>
  );
}
