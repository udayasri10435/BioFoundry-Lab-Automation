import { ProtocolStep, DeckSlot } from '../types/biotech';

export function generateOpentronsPython(steps: ProtocolStep[], deckSlots: DeckSlot[]): string {
  const codeLines: string[] = [
    `"""`,
    `Auto-generated Opentrons Python Protocol (API v2.15)`,
    `BioFoundry Lab Automation OS`,
    `Generated: ${new Date().toISOString()}`,
    `"""`,
    `from opentrons import protocol_api`,
    ``,
    `metadata = {`,
    `    'protocolName': 'BioFoundry Automated Protocol',`,
    `    'author': 'BioFoundry CAD Studio',`,
    `    'description': 'High-throughput automated liquid handling sequence',`,
    `    'apiLevel': '2.15'`,
    `}`,
    ``,
    `def run(protocol: protocol_api.ProtocolContext):`,
    `    # 1. Deck Labware Configuration`,
  ];

  // Map deck slots to labware
  deckSlots.forEach(slot => {
    if (slot.labwareType) {
      let lwDef = 'corning_96_wellplate_360ul_flat';
      if (slot.labwareType.includes('tiprack_200ul')) lwDef = 'opentrons_96_tiprack_300ul';
      else if (slot.labwareType.includes('tiprack_20ul')) lwDef = 'opentrons_96_tiprack_20ul';
      else if (slot.labwareType.includes('plate_96_pcr')) lwDef = 'nest_96_wellplate_100ul_pcr_full_skirt';
      else if (slot.labwareType.includes('plate_96_deepwell')) lwDef = 'nest_96_wellplate_2ml_deep';
      else if (slot.labwareType.includes('reservoir')) lwDef = 'nest_12_reservoir_15ml';
      else if (slot.labwareType.includes('magnetic_module')) lwDef = 'magneticModuleV2';
      else if (slot.labwareType.includes('thermocycler_module')) lwDef = 'thermocyclerModuleV2';

      if (slot.labwareType.includes('module')) {
        codeLines.push(`    mod_slot_${slot.slotNumber} = protocol.load_module('${lwDef}', '${slot.slotNumber}')`);
      } else {
        codeLines.push(`    slot_${slot.slotNumber} = protocol.load_labware('${lwDef}', '${slot.slotNumber}', '${slot.name}')`);
      }
    }
  });

  codeLines.push(``);
  codeLines.push(`    # 2. Pipette Mounts`);
  codeLines.push(`    tips_300 = protocol.load_labware('opentrons_96_tiprack_300ul', '1') if 'slot_1' in locals() else None`);
  codeLines.push(`    p300_multi = protocol.load_instrument('p300_multi_gen2', 'left', tip_racks=[tips_300] if tips_300 else [])`);
  codeLines.push(``);
  codeLines.push(`    # 3. Protocol Execution Steps`);

  steps.forEach((step, idx) => {
    codeLines.push(`    # Step ${idx + 1}: ${step.name}`);
    
    if (step.type === 'pipette_transfer' || step.type === 'multichannel_transfer') {
      const vol = step.parameters.volumeMicroLitres || 20;
      const sSlot = step.parameters.sourceSlot || 4;
      const dSlot = step.parameters.destinationSlot || 5;
      const mixCycles = step.parameters.mixCycles || 0;
      
      codeLines.push(`    # Liquid Class: ${step.parameters.liquidClass || 'water'}`);
      codeLines.push(`    p300_multi.pick_up_tip()`);
      codeLines.push(`    p300_multi.aspirate(${vol}, slot_${sSlot}.wells_by_name()['A1'])`);
      if (step.parameters.touchTip) {
        codeLines.push(`    p300_multi.touch_tip()`);
      }
      codeLines.push(`    p300_multi.dispense(${vol}, slot_${dSlot}.wells_by_name()['A1'])`);
      if (mixCycles > 0) {
        codeLines.push(`    p300_multi.mix(${mixCycles}, ${vol * 0.8})`);
      }
      codeLines.push(`    p300_multi.drop_tip()`);
    } else if (step.type === 'thermocycle') {
      const lidTemp = step.parameters.lidTemperatureCelsius || 105;
      codeLines.push(`    tc_mod = mod_slot_6  # On-Deck Thermocycler`);
      codeLines.push(`    tc_mod.set_lid_temperature(${lidTemp})`);
      if (step.parameters.stages) {
        step.parameters.stages.forEach(st => {
          codeLines.push(`    # Stage: ${st.name} (${st.cycles} cycles)`);
          const profileStr = JSON.stringify(st.steps.map(s => ({ temperature: s.temperatureCelsius, hold_time_seconds: s.holdTimeSeconds })));
          codeLines.push(`    tc_mod.execute_profile(steps=${profileStr}, repetitions=${st.cycles})`);
        });
      }
      codeLines.push(`    tc_mod.deactivate_lid()`);
    } else if (step.type === 'magnetic_bead') {
      const height = step.parameters.magnetEngageHeightMm || 12.0;
      const sepTime = (step.parameters.separationTimeMinutes || 4) * 60;
      codeLines.push(`    mag_mod = mod_slot_7  # Magnetic Module`);
      codeLines.push(`    mag_mod.engage(height_from_base=${height})`);
      codeLines.push(`    protocol.delay(seconds=${sepTime}, msg='Magnetic bead separation in progress')`);
      codeLines.push(`    mag_mod.disengage()`);
    } else if (step.type === 'incubate_shake') {
      const temp = step.parameters.temperatureCelsius || 37;
      const rpm = step.parameters.shakeRpm || 800;
      const dur = (step.parameters.shakeDurationMinutes || 10) * 60;
      codeLines.push(`    hs_mod = mod_slot_8  # Heater-Shaker Module`);
      codeLines.push(`    hs_mod.set_target_temperature(${temp})`);
      codeLines.push(`    hs_mod.set_and_wait_for_shake_speed(${rpm})`);
      codeLines.push(`    protocol.delay(seconds=${dur})`);
      codeLines.push(`    hs_mod.deactivate_shaker()`);
    }
    codeLines.push(``);
  });

  codeLines.push(`    protocol.comment("Protocol completed successfully. Clean deck and seal plates.")`);
  return codeLines.join('\n');
}

export function generateHamiltonVenus(steps: ProtocolStep[]): string {
  const venusObj = {
    methodName: "BioFoundry_HighThroughput_Run",
    version: "4.5.1",
    author: "BioFoundry CAD Engine",
    dateGenerated: new Date().toISOString(),
    liquidClassesUsed: ["StandardVolumeWater_DispenseSurface", "ViscousGlycerol_LowDispenseRate", "HighSaltDNA_AspirateJet"],
    sequences: steps.map((s, idx) => ({
      stepNumber: idx + 1,
      stepId: s.id,
      action: s.type,
      parameters: s.parameters,
      errorRecoveryMode: "Automated_Retry_Or_Pause"
    }))
  };
  return JSON.stringify(venusObj, null, 2);
}

export function generateSiLA2XML(steps: ProtocolStep[]): string {
  let xml = `<?xml version="1.0" encoding="UTF-8"?>\n<SiLACommandExecution xmlns="http://www.sila-standard.org/schema/2.0">\n`;
  xml += `  <Header>\n    <Identifier>org.silastandard/automation/orchestrator/v2</Identifier>\n    <Timestamp>${new Date().toISOString()}</Timestamp>\n  </Header>\n  <WorkflowExecution id="wf-biofoundry-01">\n`;
  
  steps.forEach((step, i) => {
    xml += `    <Command index="${i + 1}" type="${step.type}" id="${step.id}">\n`;
    xml += `      <Name>${escapeXml(step.name)}</Name>\n`;
    xml += `      <DurationSeconds>${step.durationSeconds}</DurationSeconds>\n`;
    Object.entries(step.parameters).forEach(([k, v]) => {
      xml += `      <Parameter key="${k}">${typeof v === 'object' ? JSON.stringify(v) : escapeXml(String(v))}</Parameter>\n`;
    });
    xml += `    </Command>\n`;
  });

  xml += `  </WorkflowExecution>\n</SiLACommandExecution>`;
  return xml;
}

function escapeXml(unsafe: string): string {
  return unsafe.replace(/[<>&'"]/g, (c) => {
    switch (c) {
      case '<': return '&lt;';
      case '>': return '&gt;';
      case '&': return '&amp;';
      case '\'': return '&apos;';
      case '"': return '&quot;';
      default: return c;
    }
  });
}
