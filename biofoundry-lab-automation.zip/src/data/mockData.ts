import { 
  ProtocolStep, 
  DeckSlot, 
  Instrument, 
  Microplate, 
  WorkOrder, 
  Reagent, 
  ELNAuditEntry,
  WellSample
} from '../types/biotech';

// Helper to generate 96-well plate data
export function generate96WellPlate(plateId: string, barcode: string, name: string, samplePrefix: string): Microplate {
  const rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
  const columns = Array.from({ length: 12 }, (_, i) => i + 1);
  const wells: Record<string, WellSample> = {};

  rows.forEach((row, rIdx) => {
    columns.forEach((col, cIdx) => {
      const wellId = `${row}${col}`;
      const isControlNeg = row === 'H' && (col === 11 || col === 12);
      const isControlPos = row === 'H' && (col === 9 || col === 10);
      const isEmpty = row === 'G' && col > 10;
      
      let sampleType: WellSample['sampleType'] = 'gDNA';
      let conc = Number((35 + Math.sin(rIdx * 3 + cIdx) * 25 + Math.random() * 8).toFixed(1));
      let purity = Number((1.82 + (Math.sin(rIdx + cIdx * 2) * 0.08) + Math.random() * 0.04).toFixed(2));
      let qcStatus: WellSample['qcStatus'] = 'passed';

      if (isControlNeg) {
        sampleType = 'neg_control';
        conc = 0.02;
        purity = 1.10;
      } else if (isControlPos) {
        sampleType = 'pos_control';
        conc = 50.0;
        purity = 1.86;
      } else if (isEmpty) {
        sampleType = 'empty';
        conc = 0;
        purity = 0;
        qcStatus = 'empty';
      }

      if (!isEmpty && !isControlNeg) {
        if (conc < 20 || purity < 1.70) {
          qcStatus = 'warning';
        }
        if (conc < 10 || purity < 1.60) {
          qcStatus = 'failed';
        }
      }

      const sampleNum = (rIdx * 12 + col).toString().padStart(3, '0');
      const sampleId = isEmpty ? null : `${samplePrefix}-${sampleNum}`;
      const sampleName = isEmpty ? null : isControlNeg ? 'NTC (Water)' : isControlPos ? 'PhiX Control v3' : `Cohort-Sample_${sampleNum}`;

      wells[wellId] = {
        wellId,
        row,
        column: col,
        sampleId,
        sampleName,
        organismOrConstruct: isEmpty ? undefined : (isControlNeg ? 'None' : isControlPos ? 'Bacteriophage phiX174' : 'Homo sapiens (Peripheral Blood)'),
        sampleType,
        volumeMicroLitres: isEmpty ? 0 : Number((45 - (cIdx * 0.8) + (rIdx * 0.4)).toFixed(1)),
        maxVolumeMicroLitres: 200,
        concentrationNgUl: conc,
        purityA260A280: purity,
        qcStatus,
        freezeThawCycles: isEmpty ? 0 : (col % 3 === 0 ? 3 : 1),
        parentTubeBarcode: isEmpty ? undefined : `TUBE-PRN-2026-${sampleNum}`,
        barcode: `BC-${barcode}-${wellId}`,
        notes: qcStatus === 'warning' ? 'Low purity ratio A260/A280' : undefined
      };
    });
  });

  return {
    id: plateId,
    barcode,
    name,
    format: '96',
    plateType: 'pcr',
    wells,
    createdAt: '2026-09-28T09:30:00Z',
    updatedAt: '2026-09-29T08:15:00Z',
    assignedWorkOrderId: 'WO-2026-0841'
  };
}

// Initial Genomics Protocol (Illumina TruSeq DNA Nano)
export const initialGenomicsProtocol: ProtocolStep[] = [
  {
    id: 'step-1',
    name: 'End Repair & Size Selection',
    type: 'pipette_transfer',
    description: 'Transfer 50 µL sheared gDNA and 40 µL End Repair Master Mix into 96-well reaction plate.',
    durationSeconds: 180,
    parameters: {
      sourceSlot: 4,
      sourceWellRange: 'A1:H12',
      destinationSlot: 5,
      destinationWellRange: 'A1:H12',
      volumeMicroLitres: 40.0,
      liquidClass: 'mastermix',
      aspirateSpeedMmSec: 15,
      dispenseSpeedMmSec: 20,
      tipHandling: 'change_between_columns',
      mixCycles: 5,
      mixVolumeMicroLitres: 35.0,
      touchTip: true,
      airGapMicroLitres: 2.0
    }
  },
  {
    id: 'step-2',
    name: 'End Repair Thermocycle',
    type: 'thermocycle',
    description: 'Incubate on On-Deck Thermocycler (ODTC) at 30°C for 30 min, then 4°C hold.',
    durationSeconds: 1800,
    parameters: {
      lidTemperatureCelsius: 100,
      stages: [
        {
          name: 'End Repair Hold',
          cycles: 1,
          steps: [
            { temperatureCelsius: 30.0, holdTimeSeconds: 1800 },
            { temperatureCelsius: 4.0, holdTimeSeconds: 60 }
          ]
        }
      ]
    }
  },
  {
    id: 'step-3',
    name: 'SPRI Magnetic Bead Cleanup',
    type: 'magnetic_bead',
    description: 'Add 0.8x AMPure XP beads, incubate 5 min, separate on 96-post magnet, 2x 80% EtOH wash.',
    durationSeconds: 1200,
    parameters: {
      bindingTimeMinutes: 5,
      magnetEngageHeightMm: 12.5,
      separationTimeMinutes: 4,
      washCycles: 2,
      ethanolPercentage: 80,
      dryingTimeMinutes: 3,
      elutionVolumeMicroLitres: 17.5
    }
  },
  {
    id: 'step-4',
    name: 'A-Tailing & Ligation Transfer',
    type: 'pipette_transfer',
    description: 'Transfer 15 µL purified fragments to ligation plate and dispense TruSeq DNA Adapters.',
    durationSeconds: 240,
    parameters: {
      sourceSlot: 5,
      sourceWellRange: 'A1:H12',
      destinationSlot: 6,
      destinationWellRange: 'A1:H12',
      volumeMicroLitres: 15.0,
      liquidClass: 'dna_high_salt',
      tipHandling: 'new_tip_always',
      mixCycles: 3,
      touchTip: true
    }
  },
  {
    id: 'step-5',
    name: 'Adapter Ligation Incubation',
    type: 'incubate_shake',
    description: 'Heater-shaker thermal hold at 30°C with 400 RPM orbital agitation.',
    durationSeconds: 600,
    parameters: {
      temperatureCelsius: 30.0,
      shakeRpm: 400,
      shakeDurationMinutes: 10
    }
  },
  {
    id: 'step-6',
    name: 'Final Library Quality Assay',
    type: 'plate_reader',
    description: 'Fluorescence quantification using PicoGreen dye assay at Ex485/Em528 nm.',
    durationSeconds: 150,
    parameters: {
      readMode: 'fluorescence',
      wavelengthNm: 528
    }
  }
];

// Initial Synthetic Biology Protocol (Golden Gate Assembly)
export const initialSynBioProtocol: ProtocolStep[] = [
  {
    id: 'synbio-1',
    name: 'Part Plasmids & Type IIS Enzyme Dispense',
    type: 'pipette_transfer',
    description: 'Transfer Promoters, RBS, Coding CDS, and Terminators into 96-well assembly block.',
    durationSeconds: 210,
    parameters: {
      sourceSlot: 4,
      sourceWellRange: 'A1:H12',
      destinationSlot: 5,
      destinationWellRange: 'A1:H12',
      volumeMicroLitres: 2.5,
      liquidClass: 'viscous_glycerol',
      tipHandling: 'new_tip_always',
      touchTip: true
    }
  },
  {
    id: 'synbio-2',
    name: 'BsaI / T4 Ligase Thermocycling',
    type: 'thermocycle',
    description: '35 cycles: 37°C restriction digestion (3 min) + 16°C ligation (4 min), followed by 50°C final cut & 80°C heat inactivation.',
    durationSeconds: 7200,
    parameters: {
      lidTemperatureCelsius: 105,
      stages: [
        {
          name: 'Digestion-Ligation Iterations',
          cycles: 35,
          steps: [
            { temperatureCelsius: 37.0, holdTimeSeconds: 180 },
            { temperatureCelsius: 16.0, holdTimeSeconds: 240 }
          ]
        },
        {
          name: 'Inactivation & Hold',
          cycles: 1,
          steps: [
            { temperatureCelsius: 50.0, holdTimeSeconds: 300 },
            { temperatureCelsius: 80.0, holdTimeSeconds: 600 },
            { temperatureCelsius: 4.0, holdTimeSeconds: 120 }
          ]
        }
      ]
    }
  },
  {
    id: 'synbio-3',
    name: 'Competent Cell Transformation',
    type: 'incubate_shake',
    description: 'Heat shock at 42°C for 45 sec on Heater-Shaker module, followed by ice quench & SOC outgrowth at 37°C 900 RPM.',
    durationSeconds: 3600,
    parameters: {
      temperatureCelsius: 37.0,
      shakeRpm: 900,
      shakeDurationMinutes: 60
    }
  },
  {
    id: 'synbio-4',
    name: 'Automated Colony Picking & Inoculation',
    type: 'colony_pick',
    description: 'Screen agar bioassay trays for GFP fluorescence and pick 192 positive colonies to 96-deep well blocks.',
    durationSeconds: 900,
    parameters: {
      targetCount: 192,
      fluorescenceFilter: 'GFP / EGFP 488nm'
    }
  }
];

// Initial CRO / ADME Protocol (12-Point IC50 Compound Titration)
export const initialCROProtocol: ProtocolStep[] = [
  {
    id: 'cro-1',
    name: '12-Point 1:3 Serial Dilution',
    type: 'multichannel_transfer',
    description: '8-channel pipettor transfers 10 µL compound along columns 1-12 in 384-well plate containing 20 µL buffer.',
    durationSeconds: 160,
    parameters: {
      sourceSlot: 3,
      sourceWellRange: 'A1:H1',
      destinationSlot: 5,
      destinationWellRange: 'A1:P24',
      volumeMicroLitres: 10.0,
      liquidClass: 'volatile_ethanol',
      mixCycles: 4,
      mixVolumeMicroLitres: 15.0
    }
  },
  {
    id: 'cro-2',
    name: 'HepG2 Cell Suspension Addition',
    type: 'pipette_transfer',
    description: 'Bulk dispense 25 µL / well cell suspension (5,000 cells/well) using peristaltic dispenser arm.',
    durationSeconds: 90,
    parameters: {
      sourceSlot: 3,
      destinationSlot: 5,
      volumeMicroLitres: 25.0,
      aspirateSpeedMmSec: 10,
      dispenseSpeedMmSec: 15
    }
  },
  {
    id: 'cro-3',
    name: '72-Hour CellTiter-Glo Luminescence Read',
    type: 'plate_reader',
    description: 'ATP bioluminescence measurement for cell viability & IC50 curve fitting.',
    durationSeconds: 120,
    parameters: {
      readMode: 'luminescence'
    }
  }
];

// Initial Deck Layout (12 standard ANSI/SLAS slots)
export const initialDeckSlots: DeckSlot[] = [
  {
    slotNumber: 1,
    labwareType: 'tiprack_200ul',
    name: 'Slot 1: 200µL Filter Tip Rack',
    isOccupied: true,
    currentTipsRemaining: 74,
    maxTips: 96
  },
  {
    slotNumber: 2,
    labwareType: 'tiprack_20ul',
    name: 'Slot 2: 20µL Ultra-Micro Tip Rack',
    isOccupied: true,
    currentTipsRemaining: 92,
    maxTips: 96
  },
  {
    slotNumber: 3,
    labwareType: 'reservoir_12_channel',
    name: 'Slot 3: 12-Channel Reagent Reservoir',
    isOccupied: true
  },
  {
    slotNumber: 4,
    labwareType: 'plate_96_pcr',
    name: 'Slot 4: Source Sample Plate (DNA-96)',
    isOccupied: true
  },
  {
    slotNumber: 5,
    labwareType: 'plate_96_deepwell',
    name: 'Slot 5: Reaction Plate (Working)',
    isOccupied: true
  },
  {
    slotNumber: 6,
    labwareType: 'thermocycler_module',
    name: 'Slot 6: On-Deck Thermocycler (ODTC)',
    isOccupied: true,
    moduleState: {
      temperatureCelsius: 30.0,
      targetTemperatureCelsius: 30.0
    }
  },
  {
    slotNumber: 7,
    labwareType: 'magnetic_module',
    name: 'Slot 7: MagnaRack 96 Magnetic Ring',
    isOccupied: true,
    moduleState: {
      isEngaged: true
    }
  },
  {
    slotNumber: 8,
    labwareType: 'heater_shaker_module',
    name: 'Slot 8: BioShake 3000 Module',
    isOccupied: true,
    moduleState: {
      temperatureCelsius: 37.0,
      targetTemperatureCelsius: 37.0,
      isShaking: false,
      rpm: 0
    }
  },
  {
    slotNumber: 9,
    labwareType: 'plate_384_optical',
    name: 'Slot 9: 384-Well Optical Plate',
    isOccupied: true
  },
  {
    slotNumber: 10,
    labwareType: 'tiprack_1000ul',
    name: 'Slot 10: 1000µL Deep-Well Tip Rack',
    isOccupied: true,
    currentTipsRemaining: 88,
    maxTips: 96
  },
  {
    slotNumber: 11,
    labwareType: null,
    name: 'Slot 11: Empty Deck Position',
    isOccupied: false
  },
  {
    slotNumber: 12,
    labwareType: 'trash_chute',
    name: 'Slot 12: Automated Solid Waste Chute',
    isOccupied: true
  }
];

// Instruments Fleet
export const initialInstruments: Instrument[] = [
  {
    id: 'inst-lh-01',
    name: 'Hamilton Microlab STAR',
    model: 'ML STAR V6 (8-ch + 96 MPH)',
    manufacturer: 'Hamilton Robotics',
    category: 'liquid_handler',
    status: 'running',
    silaStatus: 'connected',
    activeProtocolName: 'Illumina TruSeq DNA Nano v4.2',
    currentStepIndex: 3,
    totalSteps: 6,
    progressPercent: 58,
    elapsedSeconds: 2280,
    estimatedRemainingSeconds: 1650,
    telemetry: {
      deckTempCelsius: 22.4,
      ambientTempCelsius: 21.8,
      pressureLldMbar: 1013.2,
      wasteLevelPercent: 34,
      pipetteChannelHealth: [true, true, true, true, true, true, true, true],
      lastCalibrationDate: '2026-09-15'
    }
  },
  {
    id: 'inst-lh-02',
    name: 'Opentrons Flex Robot',
    model: 'Flex Dual 1000µL + Magnetic Module',
    manufacturer: 'Opentrons Labworks',
    category: 'liquid_handler',
    status: 'idle',
    silaStatus: 'connected',
    activeProtocolName: 'Ready for Dispatch',
    currentStepIndex: 0,
    totalSteps: 4,
    progressPercent: 0,
    elapsedSeconds: 0,
    estimatedRemainingSeconds: 0,
    telemetry: {
      deckTempCelsius: 21.9,
      ambientTempCelsius: 21.8,
      pressureLldMbar: 1012.8,
      wasteLevelPercent: 12,
      pipetteChannelHealth: [true, true],
      lastCalibrationDate: '2026-09-20'
    }
  },
  {
    id: 'inst-tc-01',
    name: 'Biometra TRobot II',
    model: 'TRobot II 96-well Automated TC',
    manufacturer: 'Analytik Jena',
    category: 'thermocycler',
    status: 'running',
    silaStatus: 'connected',
    activeProtocolName: 'NGS Index PCR (14 Cycles)',
    currentStepIndex: 2,
    totalSteps: 3,
    progressPercent: 72,
    elapsedSeconds: 1420,
    estimatedRemainingSeconds: 540,
    telemetry: {
      deckTempCelsius: 60.0,
      ambientTempCelsius: 22.0,
      pressureLldMbar: 1013.0,
      wasteLevelPercent: 0,
      pipetteChannelHealth: [],
      lastCalibrationDate: '2026-08-10'
    }
  },
  {
    id: 'inst-seq-01',
    name: 'Illumina NovaSeq X Plus',
    model: 'NovaSeq X 25B Flow Cell',
    manufacturer: 'Illumina Inc.',
    category: 'sequencer',
    status: 'running',
    silaStatus: 'connected',
    activeProtocolName: 'Paired-End 2x150bp WGS Clinical Run',
    currentStepIndex: 148,
    totalSteps: 300,
    progressPercent: 49,
    elapsedSeconds: 32400,
    estimatedRemainingSeconds: 33600,
    telemetry: {
      deckTempCelsius: 20.0,
      ambientTempCelsius: 21.5,
      pressureLldMbar: 1014.1,
      wasteLevelPercent: 48,
      pipetteChannelHealth: [],
      lastCalibrationDate: '2026-09-01'
    }
  },
  {
    id: 'inst-pr-01',
    name: 'BioTek Synergy H1',
    model: 'Synergy H1 Hybrid Multi-Mode Reader',
    manufacturer: 'Agilent Technologies',
    category: 'plate_reader',
    status: 'idle',
    silaStatus: 'connected',
    activeProtocolName: 'PicoGreen DNA Assay',
    currentStepIndex: 0,
    totalSteps: 1,
    progressPercent: 0,
    elapsedSeconds: 0,
    estimatedRemainingSeconds: 0,
    telemetry: {
      deckTempCelsius: 37.0,
      ambientTempCelsius: 22.1,
      pressureLldMbar: 1013.2,
      wasteLevelPercent: 0,
      pipetteChannelHealth: [],
      lastCalibrationDate: '2026-09-18'
    }
  },
  {
    id: 'inst-col-01',
    name: 'Molecular Devices QPix 420',
    model: 'QPix 420 High-Throughput Colony Picker',
    manufacturer: 'Molecular Devices',
    category: 'colony_picker',
    status: 'idle',
    silaStatus: 'connected',
    activeProtocolName: 'SynBio Library Pin-Transfer',
    currentStepIndex: 0,
    totalSteps: 2,
    progressPercent: 0,
    elapsedSeconds: 0,
    estimatedRemainingSeconds: 0,
    telemetry: {
      deckTempCelsius: 23.1,
      ambientTempCelsius: 22.0,
      pressureLldMbar: 1012.9,
      wasteLevelPercent: 8,
      pipetteChannelHealth: [],
      lastCalibrationDate: '2026-09-05'
    }
  }
];

// Reagent Inventory
export const initialReagents: Reagent[] = [
  {
    id: 'reag-001',
    name: 'AMPure XP Paramagnetic Beads',
    catalogNumber: 'A63881',
    lotNumber: 'LOT-2026-0814-XP',
    vendor: 'Beckman Coulter',
    expirationDate: '2027-04-15',
    storageCondition: '4°C',
    currentVolumeMl: 42.5,
    initialVolumeMl: 60.0,
    freezeThawCount: 1,
    maxFreezeThaw: 1,
    hazardClass: ['none'],
    inUseDeckSlot: 3
  },
  {
    id: 'reag-002',
    name: 'KAPA HiFi HotStart ReadyMix (2X)',
    catalogNumber: 'KK2602',
    lotNumber: 'LOT-KH-91823',
    vendor: 'Roche Diagnostics',
    expirationDate: '2027-01-30',
    storageCondition: '-20°C',
    currentVolumeMl: 14.8,
    initialVolumeMl: 25.0,
    freezeThawCount: 3,
    maxFreezeThaw: 6,
    hazardClass: ['none']
  },
  {
    id: 'reag-003',
    name: 'Absolute Ethanol 200 Proof (Molecular Grade)',
    catalogNumber: 'E7023',
    lotNumber: 'LOT-ETH-2026-09',
    vendor: 'Sigma-Aldrich',
    expirationDate: '2028-12-31',
    storageCondition: '15-25°C (Ambient)',
    currentVolumeMl: 380.0,
    initialVolumeMl: 500.0,
    freezeThawCount: 0,
    maxFreezeThaw: 99,
    hazardClass: ['flammable'],
    inUseDeckSlot: 3
  },
  {
    id: 'reag-004',
    name: 'BsaI-HFv2 Type IIS Restriction Enzyme',
    catalogNumber: 'R3733L',
    lotNumber: 'LOT-NEB-4421',
    vendor: 'New England Biolabs',
    expirationDate: '2026-12-15',
    storageCondition: '-20°C',
    currentVolumeMl: 1.2,
    initialVolumeMl: 2.5,
    freezeThawCount: 4,
    maxFreezeThaw: 5,
    hazardClass: ['none']
  },
  {
    id: 'reag-005',
    name: 'CellTiter-Glo 2.0 Viability Assay Reagent',
    catalogNumber: 'G9242',
    lotNumber: 'LOT-CTG-78012',
    vendor: 'Promega',
    expirationDate: '2026-11-20',
    storageCondition: '-20°C',
    currentVolumeMl: 85.0,
    initialVolumeMl: 100.0,
    freezeThawCount: 2,
    maxFreezeThaw: 3,
    hazardClass: ['toxic']
  }
];

// Initial Work Orders
export const initialWorkOrders: WorkOrder[] = [
  {
    id: 'wo-01',
    orderNumber: 'WO-2026-0841',
    title: 'Oncology Exome Cohort A (96 Samples)',
    assayType: 'Illumina TruSeq DNA WES',
    sampleCount: 96,
    submitter: 'Dr. Elena Rostova (Translational Genomics)',
    operator: 'Marcus Vance, Automation Spec.',
    status: 'in_progress',
    priority: 'urgent',
    createdAt: '2026-09-28T09:00:00Z',
    dueDate: '2026-09-30T17:00:00Z',
    protocolId: 'step-1',
    inputPlateBarcodes: ['PLT-96-DNA-0841'],
    outputPlateBarcodes: ['PLT-96-LIB-0841-A'],
    notes: 'Prioritize samples with high tumor cell fraction (>60%). Run dual unique indexing (UDI).'
  },
  {
    id: 'wo-02',
    orderNumber: 'WO-2026-0842',
    title: 'SynBio Metabolic Pathway Assembly (Batch 12)',
    assayType: 'Golden Gate Modular Cloning',
    sampleCount: 48,
    submitter: 'Dr. Hiroshi Tanaka (Foundry Engineering)',
    operator: 'Sarah Jenkins, Biofoundry Ops',
    status: 'queued',
    priority: 'routine',
    createdAt: '2026-09-29T07:15:00Z',
    dueDate: '2026-10-02T12:00:00Z',
    protocolId: 'synbio-1',
    inputPlateBarcodes: ['PLT-96-SYN-0012'],
    outputPlateBarcodes: ['PLT-96-GG-ASSEMBLY'],
    notes: 'Verify BsaI overhang junction integrity before heat-shock transformation into DH5a.'
  },
  {
    id: 'wo-03',
    orderNumber: 'WO-2026-0843',
    title: 'Kinase Inhibitor Profiling - 12 Compounds',
    assayType: '384-Well IC50 Titration',
    sampleCount: 384,
    submitter: 'Discovery Biology CRO Client #412',
    operator: 'David Zhang, Screening Lead',
    status: 'qc_review',
    priority: 'stat',
    createdAt: '2026-09-27T14:30:00Z',
    dueDate: '2026-09-29T18:00:00Z',
    protocolId: 'cro-1',
    inputPlateBarcodes: ['PLT-384-CPD-092'],
    outputPlateBarcodes: ['PLT-384-IC50-RES'],
    notes: 'Calculate Z-prime factor for each plate. Minimum acceptable Z-factor is 0.72.'
  }
];

// Initial ELN Audit Log
export const initialELNLogs: ELNAuditEntry[] = [
  {
    id: 'eln-1',
    timestamp: '2026-09-29T08:12:44Z',
    operator: 'Marcus Vance (ID: OP-4491)',
    action: 'Method Execution Initialized',
    details: 'Started protocol "Illumina TruSeq DNA Nano v4.2" on Hamilton STAR (inst-lh-01). Reagent lot verification passed.',
    signatureHash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    verified: true
  },
  {
    id: 'eln-2',
    timestamp: '2026-09-29T08:26:10Z',
    operator: 'Marcus Vance (ID: OP-4491)',
    action: 'Pressure LLD Calibration Verified',
    details: 'cLLD / pLLD liquid level sensing nominal across 8 channels. Delta pressure within +/- 1.2 mbar tolerance.',
    signatureHash: '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08',
    verified: true
  },
  {
    id: 'eln-3',
    timestamp: '2026-09-29T08:45:00Z',
    operator: 'Sarah Jenkins (ID: OP-3302)',
    action: 'Reagent Addition Recorded',
    details: 'Loaded Lot LOT-2026-0814-XP (AMPure XP Beads) into Deck Slot 3. Expiry date valid (2027-04-15).',
    signatureHash: '4a5e1e4baab89f3a32518a88c31bc87f618f76673e2cc77ab2127b7afdeda33b',
    verified: true
  }
];
